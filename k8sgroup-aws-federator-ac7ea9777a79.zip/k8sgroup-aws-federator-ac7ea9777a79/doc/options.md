# AWS Federator Options

Information about the available command-line options for the AWS Federator.

## Contents

- [Contents](#contents)
- [Resolution](#resolution)
- [-account](#-account)
- [-configfile](#-configfile)
- [-credentialsfile](#-credentialsfile)
- [-defaultprofile](#-defaultprofile)
- [-defaultregion](#-defaultregion)
- [-duration](#-duration)
- [-extracredentialsfile](#-extracredentialsfile)
- [-loginurl](#-loginurl)
- [-password](#-password)
- [-passwordfile](#-passwordfile)
- [-username](#-username)
- [-verbose](#-verbose)
- [-version](#-version)

## Resolution

The precedence for resolving command-line option values is as follows:

1. Value explicitly passed on the command-line
2. Value from environment variable
3. Value from plain text file (currently only used by the [`-password`](#-password) option)
4. Value from key in [configuration file](./files.md#configuration)
5. Default value

## -account

Name of the configuration account to use.

- __Type__: String
- __Environment Variable__: [`AWS_FEDERATOR_ACCOUNT`](./environment.md#aws_federator_account)
- __Plain Text File__: (None)
- __Configuration File Key__: (None)
- __Default__: "default"

## -configfile

Path of the configuration file.

- __Type__: String
- __Environment Variable__: [`AWS_FEDERATOR_CONFIG_FILE`](./environment.md#aws_federator_config_file)
- __Plain Text File__: (None)
- __Configuration File Key__: (None)
- __Default__: "~/.aws/federator/config"

## -credentialsfile

Path of the file that the AWS credentials will be written to.

- __Type__: String
- __Environment Variable__: [`AWS_SHARED_CREDENTIALS_FILE`](./environment.md#aws_shared_credentials_file)
- __Plain Text File__: (None)
- __Configuration File Key__: [`credentialsfile`](./configuration.md#credentialsfile)
- __Default__: "~/.aws/credentials"

## -defaultprofile

Name of the AWS credentials profile to set as the default.

- __Type__: String
- __Environment Variable__: [`AWS_FEDERATOR_DEFAULT_PROFILE`](./environment.md#aws_federator_default_profile)
- __Plain Text File__: (None)
- __Configuration File Key__: [`defaultprofile`](./configuration.md#defaultprofile)
- __Default__: (None)

## -defaultregion

Name of the AWS region to set as the default for each credentials profile.

- __Type__: String
- __Environment Variable__: [`AWS_FEDERATOR_DEFAULT_REGION`](./environment.md#aws_federator_default_region)
- __Plain Text File__: (None)
- __Configuration File Key__: [`defaultregion`](./configuration.md#defaultregion)
- __Default__: (None)

## -duration

Amount of time in seconds that the AWS credentials will be valid for.

- __Type__: Integer
- __Environment Variable__: [`AWS_FEDERATOR_DURATION`](./environment.md#aws_federator_duration)
- __Plain Text File__: (None)
- __Configuration File Key__: [`duration`](./configuration.md#duration)
- __Default__: 14400

## -extracredentialsfile

Path of the file containing extra AWS credentials to add to the shared AWS credentials file.

- __Type__: String
- __Environment Variable__: [`AWS_FEDERATOR_EXTRA_CREDENTIALS_FILE`](./environment.md#aws_federator_extra_credentials_file)
- __Plain Text File__: (None)
- __Configuration File Key__: [`extracredentialsfile`](./configuration.md#extracredentialsfile)
- __Default__: "~/.aws/federator/credentials"

## -loginurl

URL of the identity provider's AWS service provider login.

- __Type__: String
- __Environment Variable__: [`AWS_FEDERATOR_LOGIN_URL`](./environment.md#aws_federator_login_url)
- __Plain Text File__: (None)
- __Configuration File Key__: [`loginurl`](./configuration.md#loginurl)
- __Default__: ["https://identity.nationwide.com/idp/startSSO.ping?PartnerSpId=urn%3Aamazon%3Awebservices"](https://identity.nationwide.com/idp/startSSO.ping?PartnerSpId=urn%3Aamazon%3Awebservices)

## -password

The password to log in with.

- __Type__: String
- __Environment Variable__: [`AWS_FEDERATOR_PASSWORD`](./environment.md#aws_federator_password)
- __Plain Text File__: [Password file](./files.md#password)
- __Configuration File Key__: [`password`](./configuration.md#password)
- __Default__: (Prompt for input)

## -passwordfile

Path of the file containing the login password.

- __Type__: String
- __Environment Variable__: [`AWS_FEDERATOR_PASSWORD_FILE`](./environment.md#aws_federator_password_file)
- __Plain Text File__: (None)
- __Configuration File Key__: [`passwordfile`](./configuration.md#passwordfile)
- __Default__: "~/.aws/federator/password"

## -username

The username to log in with.

- __Type__: String
- __Environment Variable__: [`AWS_FEDERATOR_USERNAME`](./environment.md#aws_federator_username)
- __Plain Text File__: (None)
- __Configuration File Key__: [`username`](./configuration.md#username)
- __Default__: (Prompt for input)

## -verbose

Print debugging messages to standard error.

- __Type__: Boolean
- __Environment Variable__: (None)
- __Plain Text File__: (None)
- __Configuration File Key__: (None)
- __Default__: false

## -version

Print version information and exit.

- __Type__: Boolean
- __Environment Variable__: (None)
- __Plain Text File__: (None)
- __Configuration File Key__: (None)
- __Default__: false
