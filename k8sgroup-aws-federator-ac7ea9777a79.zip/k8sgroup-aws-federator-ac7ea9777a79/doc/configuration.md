# AWS Federator Configuration

Information about the available configuration file keys for the AWS Federator. Additional information about the configuration file can be found [here](./files.md#configuration).

## Contents

- [Contents](#contents)
- [Example](#example)
- [credentialsfile](#credentialsfile)
- [defaultprofile](#defaultprofile)
- [defaultregion](#defaultregion)
- [duration](#duration)
- [extracredentialsfile](#extracredentialsfile)
- [loginurl](#loginurl)
- [password](#password)
- [passwordfile](#passwordfile)
- [username](#username)

## Example

An example configuration file can be found [here](../example/config.ini).

## credentialsfile

Path of the file that the AWS credentials will be written to.

- __Type__: String

## defaultprofile

Name of the AWS credentials profile to set as the default.

- __Type__: String

## defaultregion

Name of the AWS region to set as the default for each credentials profile.

- __Type__: String

## duration

Amount of time in seconds that the AWS credentials will be valid for.

- __Type__: Integer

## extracredentialsfile

Path of the file containing extra AWS credentials to add to the shared AWS credentials file.

- __Type__: String

## loginurl

URL of the identity provider's AWS service provider login.

- __Type__: String

## password

The password to log in with.

- __Type__: String

## passwordfile

Path of the file containing the login password.

- __Type__: String

## username

The username to log in with.

- __Type__: String
