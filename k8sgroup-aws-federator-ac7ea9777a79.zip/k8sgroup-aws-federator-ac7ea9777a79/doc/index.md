# AWS Federator Documentation

Documentation for the AWS Federator.

## Pages

- [Options](./options.md): Information about the available command-line options for the AWS Federator.
- [Environment](./environment.md): Information about the available environment variables for the AWS Federator.
- [Files](./files.md): Information about the files used by the AWS Federator.
- [Configuration](./configuration.md): Information about the available configuration file keys for the AWS Federator.
