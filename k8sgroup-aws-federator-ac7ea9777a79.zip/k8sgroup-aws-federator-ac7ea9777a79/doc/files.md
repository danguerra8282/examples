# AWS Federator Files

Information about the files used by the AWS Federator.

## Contents

- [Contents](#contents)
- [Configuration](#configuration)
- [Credentials](#credentials)
- [Extra Credentials](#extra-credentials)
- [Password](#password)

## Configuration

The user configuration file for the AWS Federator. Information about the available keys for this file can be found [here](./configuration.md).

- __Format__: [INI](https://en.wikipedia.org/wiki/INI_file)
- __Default Location__: ~/.aws/federator/config
- __Example__: [config.ini](../example/config.ini)

A custom location for this file can be specified through one of the following methods (in the order of precedence):

- The [`-configfile`](./options.md#-configfile) command-line option
- The [`AWS_FEDERATOR_CONFIG_FILE`](./environment.md#aws_federator_config_file) environment variable

## Credentials

The file that the AWS credentials will be written to.

- __Format__: [INI](https://en.wikipedia.org/wiki/INI_file)
- __Default Location__: ~/.aws/credentials

A custom location for this file can be specified through one of the following methods (in the order of precedence):

- The [`-credentialsfile`](./options.md#-credentialsfile) command-line option
- The [`AWS_SHARED_CREDENTIALS_FILE`](./environment.md#aws_shared_credentials_file) environment variable
- The [`credentialsfile`](./configuration.md#credentialsfile) key in the [configuration file](#configuration)

## Extra Credentials

The file containing extra AWS credentials to add to the [shared AWS credentials file](#credentials).

- __Format__: [INI](https://en.wikipedia.org/wiki/INI_file)
- __Default Location__: ~/.aws/federator/credentials
- __Example__: [extra-credentials.ini](../example/extra-credentials.ini)

A custom location for this file can be specified through one of the following methods (in the order of precedence):

- The [`-extracredentialsfile`](./options.md#-extracredentialsfile) command-line option
- The [`AWS_FEDERATOR_EXTRA_CREDENTIALS_FILE`](./environment.md#aws_federator_extra_credentials_file) environment variable
- The [`extracredentialsfile`](./configuration.md#extracredentialsfile) key in the [configuration file](#configuration)

## Password

The file containing the login password.

Please note, all the contents of this file will be used as the password. Due to this, this file should only contain the login password.

- __Format__: Plain text
- __Default Location__: ~/.aws/federator/password
- __Example__: [password.txt](../example/password.txt)

A custom location for this file can be specified through one of the following methods (in the order of precedence):

- The [`-passwordfile`](./options.md#-passwordfile) command-line option
- The [`AWS_FEDERATOR_PASSWORD_FILE`](./environment.md#aws_federator_password_file) environment variable
- The [`passwordfile`](./configuration.md#passwordfile) key in the [configuration file](#configuration)
