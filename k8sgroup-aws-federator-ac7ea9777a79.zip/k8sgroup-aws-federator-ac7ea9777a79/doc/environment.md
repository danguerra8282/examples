# AWS Federator Environment

Information about the available environment variables for the AWS Federator.

## Contents

- [Contents](#contents)
- [AWS_FEDERATOR_ACCOUNT](#aws_federator_account)
- [AWS_FEDERATOR_CONFIG_FILE](#aws_federator_config_file)
- [AWS_SHARED_CREDENTIALS_FILE](#aws_shared_credentials_file)
- [AWS_FEDERATOR_DEFAULT_PROFILE](#aws_federator_default_profile)
- [AWS_FEDERATOR_DEFAULT_REGION](#aws_federator_default_region)
- [AWS_FEDERATOR_DURATION](#aws_federator_duration)
- [AWS_FEDERATOR_EXTRA_CREDENTIALS_FILE](#aws_federator_extra_credentials_file)
- [AWS_FEDERATOR_LOGIN_URL](#aws_federator_login_url)
- [AWS_FEDERATOR_PASSWORD](#aws_federator_password)
- [AWS_FEDERATOR_PASSWORD_FILE](#aws_federator_password_file)
- [AWS_FEDERATOR_USERNAME](#aws_federator_username)

## AWS_FEDERATOR_ACCOUNT

Name of the configuration account to use.

## AWS_FEDERATOR_CONFIG_FILE

Path of the configuration file.

## AWS_SHARED_CREDENTIALS_FILE

Path of the file that the AWS credentials will be written to.

## AWS_FEDERATOR_DEFAULT_PROFILE

Name of the AWS credentials profile to set as the default.

## AWS_FEDERATOR_DEFAULT_REGION

Name of the AWS region to set as the default for each credentials profile.

## AWS_FEDERATOR_DURATION

Amount of time in seconds that the AWS credentials will be valid for.

## AWS_FEDERATOR_EXTRA_CREDENTIALS_FILE

Path of the file containing extra AWS credentials to add to the shared AWS credentials file.

## AWS_FEDERATOR_LOGIN_URL

URL of the identity provider's AWS service provider login.

## AWS_FEDERATOR_PASSWORD

The password to log in with.

## AWS_FEDERATOR_PASSWORD_FILE

Path of the file containing the login password.

## AWS_FEDERATOR_USERNAME

The username to log in with.
