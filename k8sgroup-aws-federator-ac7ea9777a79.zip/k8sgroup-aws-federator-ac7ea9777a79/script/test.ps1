function Invoke-Main()
{
    [CmdletBinding()]

    $OriginalPWD = "$PWD"
    $ProjectDirectoryPath = Resolve-Path -Path (Join-Path -Path "$PSScriptRoot" -ChildPath "..")

    Set-Location -Path "$ProjectDirectoryPath"
    Invoke-Expression -Command "go test -timeout 60s ./..."
    Set-Location -Path "$OriginalPWD"
}

Invoke-Main
