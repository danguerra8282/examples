# Clean up the build output.

# The entry point of the script.
function Invoke-Main
{
    $ProjectDirectoryPath = Resolve-Path -Path (Join-Path -Path "$PSScriptRoot" -ChildPath "..")
    $BuildDirectoryPath = Join-Path -Path "$ProjectDirectoryPath" -ChildPath "build"

    if (Test-Path -Path "$BuildDirectoryPath")
    {
        Remove-Item -Path "$BuildDirectoryPath" -Recurse -Force
    }
}

# Invoke the entry point of the script.
Invoke-Main
