[CmdletBinding()]

param
(
    [Parameter()]
    [ValidateSet("all", "darwin-amd64", "linux-amd64", "windows-amd64")]
    [String]
    $TargetType = "all",

    [Parameter()]
    [String]
    $Version = "development"
)

$OriginalPWD = "$PWD"
$ProjectDirectoryPath = Resolve-Path -Path (Join-Path -Path "$PSScriptRoot" -ChildPath "..")
$BuildDirectoryPath = Join-Path -Path "$ProjectDirectoryPath" -ChildPath "build"
$CommandDirectoryPath = Join-Path -Path "$ProjectDirectoryPath" -ChildPath "cmd"
$AWSFederatorCommandDirectoryPath = Join-Path -Path "$CommandDirectoryPath" -ChildPath "aws-federator"
$AWSFederatorBuiltExecutableBasePath = Join-Path -Path "$BuildDirectoryPath" -ChildPath "aws-federator"

function Build-AWSFederatorExecutable
{
    [CmdletBinding()]

    param
    (
        [Parameter(Mandatory)]
        [ValidateSet("darwin", "linux", "windows")]
        [String]
        $OS,

        [Parameter(Mandatory)]
        [ValidateSet("amd64")]
        [String]
        $Architecture,

        [Parameter(Mandatory = $False)]
        [ValidateSet("", ".exe")]
        [String]
        $Extension = ""
    )

    $OriginalGoOS = "$env:GOOS"
    $OriginalGoArchitecture = "$env:GOARCH"
    $env:GOOS = "$OS"
    $env:GOARCH = "$Architecture"
    $AWSFederatorBuiltExecutablePath = "${AWSFederatorBuiltExecutableBasePath}-${Version}-${env:GOOS}-${env:GOARCH}${Extension}"

    Set-Location -Path "$AWSFederatorCommandDirectoryPath"
    Invoke-Expression -Command "go build -ldflags '-X github.nwie.net/nationwide/aws-federator/v3/federator.Version=${Version}' -o '${AWSFederatorBuiltExecutablePath}'"
    Set-Location -Path "$OriginalPWD"

    $env:GOOS = "$OriginalGoOS"
    $env:GOARCH = "$OriginalGoArchitecture"
}

if ($TargetType -eq "all")
{
    Build-AWSFederatorExecutable -OS "darwin" -Architecture "amd64"
    Build-AWSFederatorExecutable -OS "linux" -Architecture "amd64"
    Build-AWSFederatorExecutable -OS "windows" -Architecture "amd64" -Extension ".exe"
}
elseif ($TargetType -eq "darwin-amd64")
{
    Build-AWSFederatorExecutable -OS "darwin" -Architecture "amd64"
}
elseif ($TargetType -eq "linux-amd64")
{
    Build-AWSFederatorExecutable -OS "linux" -Architecture "amd64"
}
elseif ($TargetType -eq "windows-amd64")
{
    Build-AWSFederatorExecutable -OS "windows" -Architecture "amd64" -Extension ".exe"
}
