package testhelper

import (
	"os"
)

var (
	EnvironmentAccountName              = "environment-account-name"
	EnvironmentConfigurationFilePath    = "/environment/configuration/file/path"
	EnvironmentCredentialsFilePath      = "/environment/shared/credentials/file/path"
	EnvironmentDefaultProfileName       = "environment-default-profile-name"
	EnvironmentDefaultRegionName        = "environment-default-region-name"
	EnvironmentDurationSeconds          = "15"
	EnvironmentDurationSecondsInteger   = int64(15)
	EnvironmentExtraCredentialsFilePath = "/environment/extra/credentials/file/path"
	EnvironmentLoginURL                 = "environment-login-url"
	EnvironmentPassword                 = "environment-password"
	EnvironmentPasswordFilePath         = "/environment/password/file/path"
	EnvironmentUsername                 = "environment-username"
)

// SetEnvironmentVariables sets all environment variables used by the AWS
// Federator.
func SetEnvironmentVariables() error {
	err := os.Setenv("AWS_FEDERATOR_ACCOUNT", EnvironmentAccountName)
	if err != nil {
		return err
	}

	err = os.Setenv("AWS_FEDERATOR_CONFIG_FILE", EnvironmentConfigurationFilePath)
	if err != nil {
		return err
	}

	err = os.Setenv("AWS_SHARED_CREDENTIALS_FILE", EnvironmentCredentialsFilePath)
	if err != nil {
		return err
	}

	err = os.Setenv("AWS_FEDERATOR_DEFAULT_PROFILE", EnvironmentDefaultProfileName)
	if err != nil {
		return err
	}

	err = os.Setenv("AWS_FEDERATOR_DEFAULT_REGION", EnvironmentDefaultRegionName)
	if err != nil {
		return err
	}

	err = os.Setenv("AWS_FEDERATOR_DURATION", EnvironmentDurationSeconds)
	if err != nil {
		return err
	}

	err = os.Setenv("AWS_FEDERATOR_EXTRA_CREDENTIALS_FILE", EnvironmentExtraCredentialsFilePath)
	if err != nil {
		return err
	}

	err = os.Setenv("AWS_FEDERATOR_LOGIN_URL", EnvironmentLoginURL)
	if err != nil {
		return err
	}

	err = os.Setenv("AWS_FEDERATOR_PASSWORD", EnvironmentPassword)
	if err != nil {
		return err
	}

	err = os.Setenv("AWS_FEDERATOR_PASSWORD_FILE", EnvironmentPasswordFilePath)
	if err != nil {
		return err
	}

	err = os.Setenv("AWS_FEDERATOR_USERNAME", EnvironmentUsername)
	if err != nil {
		return err
	}

	return nil
}

// UnsetEnvironmentVariables unsets all environment variables used by the AWS
// Federator.
func UnsetEnvironmentVariables() error {
	err := os.Unsetenv("AWS_FEDERATOR_ACCOUNT")
	if err != nil {
		return err
	}

	err = os.Unsetenv("AWS_FEDERATOR_CONFIG_FILE")
	if err != nil {
		return err
	}

	err = os.Unsetenv("AWS_SHARED_CREDENTIALS_FILE")
	if err != nil {
		return err
	}

	err = os.Unsetenv("AWS_FEDERATOR_DEFAULT_PROFILE")
	if err != nil {
		return err
	}

	err = os.Unsetenv("AWS_FEDERATOR_DEFAULT_REGION")
	if err != nil {
		return err
	}

	err = os.Unsetenv("AWS_FEDERATOR_DURATION")
	if err != nil {
		return err
	}

	err = os.Unsetenv("AWS_FEDERATOR_EXTRA_CREDENTIALS_FILE")
	if err != nil {
		return err
	}

	err = os.Unsetenv("AWS_FEDERATOR_LOGIN_URL")
	if err != nil {
		return err
	}

	err = os.Unsetenv("AWS_FEDERATOR_PASSWORD")
	if err != nil {
		return err
	}

	err = os.Unsetenv("AWS_FEDERATOR_PASSWORD_FILE")
	if err != nil {
		return err
	}

	err = os.Unsetenv("AWS_FEDERATOR_USERNAME")
	if err != nil {
		return err
	}

	return nil
}
