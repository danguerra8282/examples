package testhelper

import (
	"github.nwie.net/nationwide/aws-federator/v3/federator"
)

// CreateCredential1 creates one of three federator.Credential objects for
// testing.
func CreateCredential1() federator.Credential {
	return federator.Credential{
		AccountNumber:   AWSAccountNumber,
		RoleName:        AWSRoleName1,
		RoleARN:         AWSRoleARN1,
		PrincipalARN:    AWSPrincipalARN,
		AccessKeyID:     AWSAccessKeyID1,
		Expiration:      CurrentTime,
		SecretAccessKey: AWSSecretAccessKey1,
		SessionToken:    AWSSessionToken1,
	}
}

// CreateCredential2 creates one of three federator.Credential objects for
// testing.
func CreateCredential2() federator.Credential {
	return federator.Credential{
		AccountNumber:   AWSAccountNumber,
		RoleName:        AWSRoleName2,
		RoleARN:         AWSRoleARN2,
		PrincipalARN:    AWSPrincipalARN,
		AccessKeyID:     AWSAccessKeyID2,
		Expiration:      CurrentTime,
		SecretAccessKey: AWSSecretAccessKey2,
		SessionToken:    AWSSessionToken2,
	}
}

// CreateCredential3 creates one of three federator.Credential objects for
// testing.
func CreateCredential3() federator.Credential {
	return federator.Credential{
		AccountNumber:   AWSAccountNumber,
		RoleName:        AWSRoleName3,
		RoleARN:         AWSRoleARN3,
		PrincipalARN:    AWSPrincipalARN,
		AccessKeyID:     AWSAccessKeyID3,
		Expiration:      CurrentTime,
		SecretAccessKey: AWSSecretAccessKey3,
		SessionToken:    AWSSessionToken3,
	}
}
