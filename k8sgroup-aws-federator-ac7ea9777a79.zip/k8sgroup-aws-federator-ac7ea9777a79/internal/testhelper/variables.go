package testhelper

import (
	"path/filepath"
	"runtime"
	"strings"
	"time"
)

var (
	// Internal file system paths for testing.
	_, currentFilePath, _, _            = runtime.Caller(0)
	currentFileDirectoryPath, cfdpError = filepath.Abs(filepath.Dir(currentFilePath))

	// ProjectRootDirectoryPath is the file system path of the root project
	// directory.
	ProjectRootDirectoryPath, prdpError = filepath.Abs(filepath.Join(currentFileDirectoryPath, "..", ".."))

	// PackageDirectoryPath is the file system path of the project's package
	// directory.
	PackageDirectoryPath = ProjectRootDirectoryPath

	// FederatorPackageDirectoryPath is the file system path of the project's
	// federator package directory.
	FederatorPackageDirectoryPath = filepath.Join(PackageDirectoryPath, "federator")

	// TestDataDirectoryPath is the file system path of the project's test data
	// directory.
	TestDataDirectoryPath = filepath.Join(ProjectRootDirectoryPath, "testdata")

	// AppendFilePath is the file system path of the text file for testing
	// appending data to.
	AppendFilePath = filepath.Join(TestDataDirectoryPath, "append.txt")

	// EmptyTextFilePath is the file system path of an empty text file for
	// testing.
	EmptyTextFilePath = filepath.Join(TestDataDirectoryPath, "empty.txt")

	// ExtraCredentialsFilePath is the file system path of the extra credentials
	// file for testing.
	ExtraCredentialsFilePath = filepath.Join(TestDataDirectoryPath, "extra-credentials.ini")

	// NonExistentTextFilePath is the file system path of a file that does not
	// exist.
	NonExistentTextFilePath = filepath.Join(TestDataDirectoryPath, "non-existent.txt")

	// NewDirectoryPath is the file system path of a directory to be created for
	// testing.
	NewDirectoryPath = filepath.Join(TestDataDirectoryPath, "new")

	// NewTextFilePath is the file system path of a new text file to be created
	// for testing.
	NewTextFilePath = filepath.Join(TestDataDirectoryPath, "new.txt")

	// SimpleTextFilePath is the file system path of a simple text file for
	// testing.
	SimpleTextFilePath = filepath.Join(TestDataDirectoryPath, "simple.txt")

	// ConfigurationFilePath is the file system path of the configuration file
	// for testing.
	ConfigurationFilePath = filepath.Join(TestDataDirectoryPath, "configuration.ini")

	// CredentialsFilePath is the file system path of the credentials file for
	// testing.
	CredentialsFilePath = filepath.Join(TestDataDirectoryPath, "credentials.ini")

	// NewCredentialsFilePath is the file system path of the credentials file
	// for testing.
	NewCredentialsFilePath = filepath.Join(TestDataDirectoryPath, "new-credentials.ini")

	// PasswordFilePath is the file system path of the password file for
	// testing.
	PasswordFilePath = filepath.Join(TestDataDirectoryPath, "password.txt")

	// EmptyCredentialsFilePath is the file system path of an empty credentials
	// file for testing.
	EmptyCredentialsFilePath = filepath.Join(TestDataDirectoryPath, "empty-credentials.ini")

	// AWSRegionName is the AWS region name used for testing.
	AWSRegionName = "us-east-1"

	// AWSAccountNumber is the AWS account number used for testing.
	AWSAccountNumber = "123456789012"

	// AWSPrincipalARN is AWS pricipal ARN used for testing.
	AWSPrincipalARN = strings.Join([]string{"arn:aws:iam::", AWSAccountNumber, ":saml-provider/saml-provider-name"}, "")

	// AWSRoleBaseARN is the base role ARN used for testing.
	AWSRoleBaseARN = strings.Join([]string{"arn:aws:iam::", AWSAccountNumber, ":role"}, "")

	// AWSRoleName1 is one of three AWS role names used for testing.
	AWSRoleName1 = "role-name+1"

	// AWSRoleARN1 is one of three AWS role ARNs used for testing.
	AWSRoleARN1 = strings.Join([]string{AWSRoleBaseARN, AWSRoleName1}, "/")

	// AWSSAMLRoleAttributeValue1 is one of three AWS SAML role attribute values
	// used for testing.
	AWSSAMLRoleAttributeValue1 = strings.Join([]string{AWSRoleARN1, AWSPrincipalARN}, ",")

	// AWSAccessKeyID1 is one of three AWS access key identifiers used for
	// testing.
	AWSAccessKeyID1 = "AWSAccessKeyIdentifier1"

	// AWSSecretAccessKey1 is one of three AWS secret access keys used for
	// testing.
	AWSSecretAccessKey1 = "AWSSecretAccessKey1"

	// AWSSessionToken1 is one of three AWS session tokens used for testing.
	AWSSessionToken1 = "AWSSessionToken1"

	// AWSProfileName1 is one of three AWS profile names used for testing.
	AWSProfileName1 = "aws-profile-name-1"

	// AWSRoleName2 is one of three AWS role names used for testing.
	AWSRoleName2 = "RoleName@2"

	// AWSRoleARN2 is one of three AWS role ARNs used for testing.
	AWSRoleARN2 = strings.Join([]string{AWSRoleBaseARN, AWSRoleName2}, "/")

	// AWSSAMLRoleAttributeValue2 is one of three AWS SAML role attribute values
	// used for testing.
	AWSSAMLRoleAttributeValue2 = strings.Join([]string{AWSRoleARN2, AWSPrincipalARN}, ",")

	// AWSAccessKeyID2 is one of three AWS access key identifiers used for
	// testing.
	AWSAccessKeyID2 = "AWSAccessKeyIdentifier2"

	// AWSSecretAccessKey2 is one of three AWS secret access keys used for
	// testing.
	AWSSecretAccessKey2 = "AWSSecretAccessKey2"

	// AWSSessionToken2 is one of three AWS session tokens used for testing.
	AWSSessionToken2 = "AWSSessionToken2"

	// AWSProfileName2 is one of three AWS profile names used for testing.
	AWSProfileName2 = "aws-profile-name-2"

	// AWSRoleName3 is one of three AWS role names used for testing.
	AWSRoleName3 = "role_name.3"

	// AWSRoleARN3 is one of three AWS role ARNs used for testing.
	AWSRoleARN3 = strings.Join([]string{AWSRoleBaseARN, AWSRoleName3}, "/")

	// AWSSAMLRoleAttributeValue3 is one of three AWS SAML role attribute values
	// used for testing.
	AWSSAMLRoleAttributeValue3 = strings.Join([]string{AWSRoleARN3, AWSPrincipalARN}, ",")

	// AWSAccessKeyID3 is one of three AWS access key identifiers used for
	// testing.
	AWSAccessKeyID3 = "AWSAccessKeyIdentifier3"

	// AWSSecretAccessKey3 is one of three AWS secret access keys used for
	// testing.
	AWSSecretAccessKey3 = "AWSSecretAccessKey3"

	// AWSSessionToken3 is one of three AWS session tokens used for testing.
	AWSSessionToken3 = "AWSSessionToken3"

	// AWSProfileName3 is one of three AWS profile names used for testing.
	AWSProfileName3 = "aws-profile-name-3"

	// EmptyString is an empty string for testing.
	EmptyString = ""

	// CurrentTime is the current local time for testing.
	CurrentTime = time.Now()
)
