# AWS Federator

Easily manage federated AWS credentials from the command-line.

## Contents

- [Contents](#contents)
- [Installation](#installation)
  - [Manual](#manual)
  - [Homebrew](#homebrew)
  - [Scoop](#scoop)
- [Usage](#usage)
- [Documentation](#documentation)
- [Examples](#examples)
- [Credits](#credits)

## Installation

### Manual

Download an executable from the [releases page](https://github.aepsc.com/AEP/aws-federator/releases) for the appropriate operating system and architecture. The following optional steps are recommended for easier usage of the executable:

- Rename the executable.
  - `aws-federator` for the Darwin (i.e. macOS) and Linux operating systems.
  - `aws-federator.exe` for the Windows operating system.
- Place the executable in a directory located in your [`PATH` environment variable](https://en.wikipedia.org/wiki/PATH_(variable)).

### Homebrew

[Homebrew](https://brew.sh) is a package manager for Linux and macOS. Follow [these instructions](https://docs.brew.sh/Installation) to install it.

Once Homebrew is installed and the [AEP Homebrew tap](https://github.aepsc.com/AEP/homebrew-aep) is [installed](https://github.aepsc.com/AEP/homebrew-aep#installation), install it from the command-line:

```shell
brew install aep/aep/aws-federator
```

### Scoop

[Scoop](http://scoop.sh) is a command-line installer for Windows. Follow [these instructions](https://github.com/lukesampson/scoop/wiki/Quick-Start) to install it.

Once Scoop is installed and the [AEP Scoop bucket](https://github.aepsc.com/AEP/scoop-aep) is [added as a local bucket](https://github.aepsc.com/AEP/scoop-aep#installation), install it from the command-line:

```shell
scoop install aws-federator
```

## Usage

If running from an on-premises location, ensure the `https_proxy` environment variable is set to one of the following values:

- URL of AEP's internal proxy (i.e. `http://http-proxy.aepsc.com:8080`)
- URL of AEP's [iboss](https://www.iboss.com) cloud proxy (i.e. `https://cloud-cluster122197-swg.ibosscloud.com:8009`)
- URL of a local proxy service, such as [Cntlm](http://cntlm.sourceforge.net) (e.g. `http://localhost:3128`)

Once this is complete, invoke the executable from the command-line with the desired [options](./doc/options.md):

```shell
aws-federator [<options>]
```

## Documentation

Documentation for the AWS Federator can be found [here](./doc/index.md).

## Examples

The simplest possible example:

```shell
aws-federator
```

A simple Windows example using a custom [configuration file](./doc/files.md#configuration) location:

```shell
aws-federator.exe -configfile "C:\Users\s311655\.aws\federator\config.ini"
```

An example of a working [configuration file](./doc/files.md#configuration) can be found [here](https://gist.github.aepsc.com/s311655/20c516a857615601000c1612db03219e). Additional examples can be found [here](./example).

## Credits

Inspired by and borrowed from:

- [AWS CLI Federator](https://github.com/aidan-/aws-cli-federator)
- [How to Implement Federated API and CLI Access Using SAML 2.0 and AD FS](https://aws.amazon.com/blogs/security/how-to-implement-federated-api-and-cli-access-using-saml-2-0-and-ad-fs/)
