package federator_test

import (
	"testing"

	"github.nwie.net/nationwide/aws-federator/v3/federator"
	"github.nwie.net/nationwide/aws-federator/v3/internal/testhelper"
)

// TestRoleARN tests the federator.Role.RoleARN method.
func TestRoleARN(t *testing.T) {
	role1 := federator.Role(testhelper.AWSSAMLRoleAttributeValue1)
	role2 := federator.Role(testhelper.AWSSAMLRoleAttributeValue2)
	role3 := federator.Role(testhelper.AWSSAMLRoleAttributeValue3)

	if role1.RoleARN() != testhelper.AWSRoleARN1 {
		t.Fatalf("incorrect role ARN returned\ngot: %s\nexpected: %s", role1.RoleARN(), testhelper.AWSRoleARN1)
	}

	if role2.RoleARN() != testhelper.AWSRoleARN2 {
		t.Fatalf("incorrect role ARN returned\ngot: %s\nexpected: %s", role2.RoleARN(), testhelper.AWSRoleARN2)
	}

	if role3.RoleARN() != testhelper.AWSRoleARN3 {
		t.Fatalf("incorrect role ARN returned\ngot: %s\nexpected: %s", role3.RoleARN(), testhelper.AWSRoleARN3)
	}
}

// TestPrincipalARN tests the federator.Role.PrincipalARN method.
func TestPrincipalARN(t *testing.T) {
	role1 := federator.Role(testhelper.AWSSAMLRoleAttributeValue1)
	role2 := federator.Role(testhelper.AWSSAMLRoleAttributeValue2)
	role3 := federator.Role(testhelper.AWSSAMLRoleAttributeValue3)

	if role1.PrincipalARN() != testhelper.AWSPrincipalARN {
		t.Fatalf("incorrect principal ARN returned\ngot: %s\nexpected: %s", role1.PrincipalARN(), testhelper.AWSPrincipalARN)
	}

	if role2.PrincipalARN() != testhelper.AWSPrincipalARN {
		t.Fatalf("incorrect principal ARN returned\ngot: %s\nexpected: %s", role2.PrincipalARN(), testhelper.AWSPrincipalARN)
	}

	if role3.PrincipalARN() != testhelper.AWSPrincipalARN {
		t.Fatalf("incorrect principal ARN returned\ngot: %s\nexpected: %s", role3.PrincipalARN(), testhelper.AWSPrincipalARN)
	}
}

// TestAccountNumber tests the federator.Role.AccountNumber method.
func TestAccountNumber(t *testing.T) {
	role1 := federator.Role(testhelper.AWSSAMLRoleAttributeValue1)
	role2 := federator.Role(testhelper.AWSSAMLRoleAttributeValue2)
	role3 := federator.Role(testhelper.AWSSAMLRoleAttributeValue3)

	if role1.AccountNumber() != testhelper.AWSAccountNumber {
		t.Fatalf("incorrect account number returned\ngot: %s\nexpected: %s", role1.AccountNumber(), testhelper.AWSAccountNumber)
	}

	if role2.AccountNumber() != testhelper.AWSAccountNumber {
		t.Fatalf("incorrect account number returned\ngot: %s\nexpected: %s", role2.AccountNumber(), testhelper.AWSAccountNumber)
	}

	if role3.AccountNumber() != testhelper.AWSAccountNumber {
		t.Fatalf("incorrect account number returned\ngot: %s\nexpected: %s", role3.AccountNumber(), testhelper.AWSAccountNumber)
	}
}

// TestRoleName tests the federator.Role.RoleName method.
func TestRoleName(t *testing.T) {
	role1 := federator.Role(testhelper.AWSSAMLRoleAttributeValue1)
	role2 := federator.Role(testhelper.AWSSAMLRoleAttributeValue2)
	role3 := federator.Role(testhelper.AWSSAMLRoleAttributeValue3)

	if role1.RoleName() != testhelper.AWSRoleName1 {
		t.Fatalf("incorrect role name returned\ngot: %s\nexpected: %s", role1.RoleName(), testhelper.AWSRoleName1)
	}

	if role2.RoleName() != testhelper.AWSRoleName2 {
		t.Fatalf("incorrect role name returned\ngot: %s\nexpected: %s", role2.RoleName(), testhelper.AWSRoleName2)
	}

	if role3.RoleName() != testhelper.AWSRoleName3 {
		t.Fatalf("incorrect role name returned\ngot: %s\nexpected: %s", role3.RoleName(), testhelper.AWSRoleName3)
	}
}
