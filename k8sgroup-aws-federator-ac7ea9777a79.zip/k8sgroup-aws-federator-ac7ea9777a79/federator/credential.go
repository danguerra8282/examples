package federator

import (
	"time"
)

// Credential represents a temporary AWS credential.
type Credential struct {
	AccountNumber   string
	RoleName        string
	RoleARN         string
	PrincipalARN    string
	AccessKeyID     string
	Expiration      time.Time
	SecretAccessKey string
	SessionToken    string
}
