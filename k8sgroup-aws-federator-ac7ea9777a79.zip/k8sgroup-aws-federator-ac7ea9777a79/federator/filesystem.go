package federator

import (
	"io/ioutil"
	"os"
)

// AppendToFile appends data to a file.
func AppendToFile(path string, data string) error {
	file, err := os.OpenFile(path, os.O_APPEND|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}

	defer file.Close()

	_, err = file.WriteString(data)
	if err != nil {
		return err
	}

	return nil
}

// CreateDirectoryIfNotExists creates a file system directory and all necessary
// parent directories if it does not already exist at the specified path.
func CreateDirectoryIfNotExists(path string, mode os.FileMode) error {
	if !FileSystemPathExists(path) {
		var err = os.MkdirAll(path, mode)

		if err != nil {
			return err
		}
	}

	return nil
}

// CreateFileIfNotExists creates a file if it does not already exist at the
// specified path.
func CreateFileIfNotExists(path string) error {
	if !FileSystemPathExists(path) {
		var file, err = os.Create(path)

		if err != nil {
			return err
		}

		defer file.Close()
	}

	return nil
}

// FileSystemPathExists checks if a file system path exists.
func FileSystemPathExists(path string) bool {
	_, err := os.Stat(path)

	if os.IsNotExist(err) {
		return false
	}

	return true
}

// GetFileSystemItemMode gets the mode of a file system item.
func GetFileSystemItemMode(path string) (os.FileMode, error) {
	fileSystemItemInformation, err := os.Stat(path)

	if err != nil {
		return os.FileMode(int(0000)), err
	}

	return fileSystemItemInformation.Mode(), nil
}

// ReadFile reads a file and returns its data as a string.
func ReadFile(path string) (string, error) {
	data, err := ioutil.ReadFile(path)

	if err != nil {
		return "", err
	}

	return string(data), err
}

// RemoveFileSystemItemIfExists removes a file system item if it exists.
func RemoveFileSystemItemIfExists(path string) error {
	if FileSystemPathExists(path) {
		var err = os.Remove(path)

		if err != nil {
			return err
		}
	}

	return nil
}
