package federator

import (
	"path/filepath"
)

var (
	// DefaultAccountName is the default name the configuration account to use.
	DefaultAccountName = "default"

	// DefaultConfigurationFilePath is the path of the default configuration
	// file.
	DefaultConfigurationFilePath = filepath.Join(currentUserHomePath, ".aws", "federator", "config")

	// DefaultCredentialsFilePath is the path of the default credentials file.
	DefaultCredentialsFilePath = filepath.Join(currentUserHomePath, ".aws", "credentials")

	// DefaultDurationSeconds is the default amount of time in seconds that the
	// credentials are valid for.
	DefaultDurationSeconds = int64(14400) // 14,400 seconds = 4 hours

	// DefaultExtraCredentialsFilePath is the path of the default extra
	// credentials file.
	DefaultExtraCredentialsFilePath = filepath.Join(currentUserHomePath, ".aws", "federator", "credentials")

	// DefaultLoginURL is the URL of the default identity provider login.
	DefaultLoginURL = "https://identity.nationwide.com/idp/startSSO.ping?PartnerSpId=urn%3Aamazon%3Awebservices"

	// DefaultPasswordFilePath is the path of the default password file.
	DefaultPasswordFilePath = filepath.Join(currentUserHomePath, ".aws", "federator", "password")

	// DefaultProxyURL is the URL of the default proxy.
	DefaultProxyURL = "http://http-proxy.nwie.net:8080"
)
