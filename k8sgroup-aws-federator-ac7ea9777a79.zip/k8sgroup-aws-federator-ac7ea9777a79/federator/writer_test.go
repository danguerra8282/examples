package federator_test

import (
	"reflect"
	"testing"

	"github.nwie.net/nationwide/aws-federator/v3/federator"
	"github.nwie.net/nationwide/aws-federator/v3/internal/testhelper"
	"gopkg.in/ini.v1"
)

// createCredentialsFile creates an empty credentials file for testing.
func createCredentialsFile(t *testing.T) {
	err := federator.CreateFileIfNotExists(testhelper.NewCredentialsFilePath)
	if err != nil {
		t.Fatalf("error occurred while creating '%s': %s", testhelper.NewCredentialsFilePath, err)
	}
}

// createWriterWithoutRegion creates a new federator.Writer without an AWS
// region for testing.
func createWriterWithoutRegion(t *testing.T) federator.Writer {
	federatorWriter, err := federator.NewWriter(testhelper.NewCredentialsFilePath, testhelper.EmptyString)
	if err != nil {
		t.Fatalf("error occurred while creating writer: %s", err)
	}

	return federatorWriter
}

// createWriterWithRegion creates a new federator.Writer with an AWS region for
// testing.
func createWriterWithRegion(t *testing.T) federator.Writer {
	federatorWriter, err := federator.NewWriter(testhelper.NewCredentialsFilePath, testhelper.AWSRegionName)
	if err != nil {
		t.Fatalf("error occurred while creating writer: %s", err)
	}

	return federatorWriter
}

// recreateCredentialsFile recreates an empty credentials file for testing.
func recreateCredentialsFile(t *testing.T) {
	removeCredentialsFile(t)
	createCredentialsFile(t)
}

// removeCredentialsFile removes the credentials file for testing.
func removeCredentialsFile(t *testing.T) {
	err := federator.RemoveFileSystemItemIfExists(testhelper.NewCredentialsFilePath)
	if err != nil {
		t.Fatalf("error occurred while removing '%s': %s", testhelper.NewCredentialsFilePath, err)
	}
}

// TestNewWriter tests the NewWriter function from the federator package.
func TestNewWriter(t *testing.T) {
	// Create a new federator.Writer.
	federatorWriter, err := federator.NewWriter(testhelper.EmptyCredentialsFilePath, testhelper.AWSRegionName)

	// Ensure no error occurred while creating the new federator.Writer.
	if err != nil {
		t.Fatalf("error occurred while creating writer: %s", err)
	}

	// Ensure a federator.Writer type was returned.
	if reflect.TypeOf(federatorWriter).String() != "federator.Writer" {
		t.Fatal("did not return 'federator.Writer' type")
	}

	// Ensure the writer's file path was correctly initialized.
	if federatorWriter.FilePath != testhelper.EmptyCredentialsFilePath {
		t.Fatalf("writer initialized with incorrect file path\ngot: %s\nexpected: %s", federatorWriter.FilePath, testhelper.EmptyCredentialsFilePath)
	}

	// Ensure the writer's region name was correctly initialized.
	if federatorWriter.RegionName != testhelper.AWSRegionName {
		t.Fatalf("writer initialized with incorrect region name\ngot: %s\nexpected: %s", federatorWriter.RegionName, testhelper.AWSRegionName)
	}
}

// TestWriterWrite tests the federator.Writer.Write method.
func TestWriterWrite(t *testing.T) {
	// Create the writers for testing.
	writerWithoutRegion := createWriterWithoutRegion(t)
	writerWithRegion := createWriterWithRegion(t)

	// Create credentials for testing.
	credential1 := testhelper.CreateCredential1()
	credential2 := testhelper.CreateCredential2()

	// Recreate an empty credentials file for the first round of testing.
	recreateCredentialsFile(t)

	// Create write inputs for testing.
	writeInput1WithProfileName := federator.WriteInput{
		CredentialStructure: credential1,
		ProfileName:         testhelper.AWSProfileName1,
	}
	writeInput2WithoutProfileName := federator.WriteInput{
		CredentialStructure: credential2,
	}

	// Write input one with profile name and without region.
	err := writerWithoutRegion.Write(writeInput1WithProfileName)

	// Ensure no error occurred while writing the first credential.
	if err != nil {
		t.Fatalf("error occurred while writing credential to '%s': %s", testhelper.NewCredentialsFilePath, err)
	}

	// Load the first credential written to file.
	iniFile1, err := ini.Load(testhelper.NewCredentialsFilePath)
	if err != nil {
		t.Fatalf("error occurred while loading '%s': %s", testhelper.NewCredentialsFilePath, err)
	}

	// Get the INI section for the first credential profile.
	iniSection1, err := iniFile1.GetSection(testhelper.AWSProfileName1)

	// Ensure the correct profile name was written for the first credential.
	if err != nil {
		t.Fatalf("error occurred while getting '%s' section from '%s': %s", testhelper.AWSProfileName1, testhelper.NewCredentialsFilePath, err)
	}

	// Ensure the first credential profile's aws_access_key_id key is correct.
	if iniSection1.Key("aws_access_key_id").Value() != testhelper.AWSAccessKeyID1 {
		t.Fatalf("'aws_access_key_id' is incorrect\ngot: %s\nexpected: %s", iniSection1.Key("aws_access_key_id").Value(), testhelper.AWSAccessKeyID1)
	}

	// Ensure the first credential profile's aws_secret_access_key key is correct.
	if iniSection1.Key("aws_secret_access_key").Value() != testhelper.AWSSecretAccessKey1 {
		t.Fatalf("'aws_secret_access_key' is incorrect\ngot: %s\nexpected: %s", iniSection1.Key("aws_secret_access_key").Value(), testhelper.AWSSecretAccessKey1)
	}

	// Ensure the first credential profile's aws_session_token key is correct.
	if iniSection1.Key("aws_session_token").Value() != testhelper.AWSSessionToken1 {
		t.Fatalf("'aws_session_token' is incorrect\ngot: %s\nexpected: %s", iniSection1.Key("aws_session_token").Value(), testhelper.AWSSessionToken1)
	}

	// Ensure the first credential profile does not have a region key.
	if iniSection1.HasKey("region") {
		t.Fatalf("'%s' section in the '%s' file has a 'region' key", testhelper.AWSProfileName1, testhelper.NewCredentialsFilePath)
	}

	// Recreate an empty credentials file for the second round of testing.
	recreateCredentialsFile(t)

	// Write input two without a profile name and with region.
	err = writerWithRegion.Write(writeInput2WithoutProfileName)

	// Ensure no error occurred while writing the second credential.
	if err != nil {
		t.Fatalf("error occurred while writing credential to '%s': %s", testhelper.NewCredentialsFilePath, err)
	}

	// Load the second credential written to file.
	iniFile2, err := ini.Load(testhelper.NewCredentialsFilePath)
	if err != nil {
		t.Fatalf("error occurred while loading '%s': %s", testhelper.NewCredentialsFilePath, err)
	}

	// Get the INI section for the second credential profile.
	iniSection2, err := iniFile2.GetSection(writeInput2WithoutProfileName.CredentialStructure.RoleName)

	// Ensure the correct profile name was written for the second credential.
	if err != nil {
		t.Fatalf("error occurred while getting '%s' section from '%s': %s", writeInput2WithoutProfileName.CredentialStructure.RoleName, testhelper.NewCredentialsFilePath, err)
	}

	// Ensure the second credential profile's aws_access_key_id key is correct.
	if iniSection2.Key("aws_access_key_id").Value() != testhelper.AWSAccessKeyID2 {
		t.Fatalf("'aws_access_key_id' is incorrect\ngot: %s\nexpected: %s", iniSection2.Key("aws_access_key_id").Value(), testhelper.AWSAccessKeyID2)
	}

	// Ensure the second credential profile's aws_secret_access_key key is correct.
	if iniSection2.Key("aws_secret_access_key").Value() != testhelper.AWSSecretAccessKey2 {
		t.Fatalf("'aws_secret_access_key' is incorrect\ngot: %s\nexpected: %s", iniSection2.Key("aws_secret_access_key").Value(), testhelper.AWSSecretAccessKey2)
	}

	// Ensure the second credential profile's aws_session_token key is correct.
	if iniSection2.Key("aws_session_token").Value() != testhelper.AWSSessionToken2 {
		t.Fatalf("'aws_session_token' is incorrect\ngot: %s\nexpected: %s", iniSection2.Key("aws_session_token").Value(), testhelper.AWSSessionToken2)
	}

	// Ensure the second credential profile's region key is correct.
	if iniSection2.Key("region").Value() != testhelper.AWSRegionName {
		t.Fatalf("'region' is incorrect\ngot: %s\nexpected: %s", iniSection2.Key("region").Value(), testhelper.AWSRegionName)
	}

	// Remove the test credentials file.
	removeCredentialsFile(t)
}

// TestWriterBatchWrite tests the federator.Writer.BatchWrite method.
func TestWriterBatchWrite(t *testing.T) {
	// Create the writers for testing.
	writerWithoutRegion := createWriterWithoutRegion(t)
	// writerWithRegion := createWriterWithRegion(t)

	// Create credential array for testing.
	credentials := []federator.Credential{
		testhelper.CreateCredential1(),
		testhelper.CreateCredential2(),
	}

	// Recreate an empty credentials file for testing.
	recreateCredentialsFile(t)

	// Write input one with profile name and without region.
	err := writerWithoutRegion.BatchWrite(credentials)

	// Ensure no error occurred while writing the first credential.
	if err != nil {
		t.Fatalf("error occurred while writing credential to '%s': %s", testhelper.NewCredentialsFilePath, err)
	}

	// Load the first credential written to file.
	iniFile1, err := ini.Load(testhelper.NewCredentialsFilePath)
	if err != nil {
		t.Fatalf("error occurred while loading '%s': %s", testhelper.NewCredentialsFilePath, err)
	}

	// Get the INI section for the first credential profile.
	iniSection1, err := iniFile1.GetSection(testhelper.AWSRoleName1)

	// Ensure the correct profile name was written for the first credential.
	if err != nil {
		t.Fatalf("error occurred while getting '%s' section from '%s': %s", testhelper.AWSRoleName1, testhelper.NewCredentialsFilePath, err)
	}

	// Ensure the first credential profile's aws_access_key_id key is correct.
	if iniSection1.Key("aws_access_key_id").Value() != testhelper.AWSAccessKeyID1 {
		t.Fatalf("'aws_access_key_id' is incorrect\ngot: %s\nexpected: %s", iniSection1.Key("aws_access_key_id").Value(), testhelper.AWSAccessKeyID1)
	}

	// Ensure the first credential profile's aws_secret_access_key key is correct.
	if iniSection1.Key("aws_secret_access_key").Value() != testhelper.AWSSecretAccessKey1 {
		t.Fatalf("'aws_secret_access_key' is incorrect\ngot: %s\nexpected: %s", iniSection1.Key("aws_secret_access_key").Value(), testhelper.AWSSecretAccessKey1)
	}

	// Ensure the first credential profile's aws_session_token key is correct.
	if iniSection1.Key("aws_session_token").Value() != testhelper.AWSSessionToken1 {
		t.Fatalf("'aws_session_token' is incorrect\ngot: %s\nexpected: %s", iniSection1.Key("aws_session_token").Value(), testhelper.AWSSessionToken1)
	}

	// Ensure the first credential profile does not have a region key.
	if iniSection1.HasKey("region") {
		t.Fatalf("'%s' section in the '%s' file has a 'region' key", testhelper.AWSProfileName1, testhelper.NewCredentialsFilePath)
	}

	// Get the INI section for the second credential profile.
	iniSection2, err := iniFile1.GetSection(testhelper.AWSRoleName2)

	// Ensure the correct profile name was written for the second credential.
	if err != nil {
		t.Fatalf("error occurred while getting '%s' section from '%s': %s", testhelper.AWSRoleName2, testhelper.NewCredentialsFilePath, err)
	}

	// Ensure the second credential profile's aws_access_key_id key is correct.
	if iniSection2.Key("aws_access_key_id").Value() != testhelper.AWSAccessKeyID2 {
		t.Fatalf("'aws_access_key_id' is incorrect\ngot: %s\nexpected: %s", iniSection2.Key("aws_access_key_id").Value(), testhelper.AWSAccessKeyID2)
	}

	// Ensure the second credential profile's aws_secret_access_key key is correct.
	if iniSection2.Key("aws_secret_access_key").Value() != testhelper.AWSSecretAccessKey2 {
		t.Fatalf("'aws_secret_access_key' is incorrect\ngot: %s\nexpected: %s", iniSection2.Key("aws_secret_access_key").Value(), testhelper.AWSSecretAccessKey2)
	}

	// Ensure the second credential profile's aws_session_token key is correct.
	if iniSection2.Key("aws_session_token").Value() != testhelper.AWSSessionToken2 {
		t.Fatalf("'aws_session_token' is incorrect\ngot: %s\nexpected: %s", iniSection2.Key("aws_session_token").Value(), testhelper.AWSSessionToken2)
	}

	// Ensure the second credential profile does not have a region key.
	if iniSection1.HasKey("region") {
		t.Fatalf("'%s' section in the '%s' file has a 'region' key", testhelper.AWSProfileName1, testhelper.NewCredentialsFilePath)
	}

	// Remove the test credentials file.
	removeCredentialsFile(t)
}
