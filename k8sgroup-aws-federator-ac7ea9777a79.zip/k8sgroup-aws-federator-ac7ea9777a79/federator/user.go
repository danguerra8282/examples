package federator

import (
	"log"
	"os/user"
	"strings"
)

var (
	currentUserHomePath = getCurrentUserHomePath()
	currentUserUsername = getCurrentUserUsername()
)

// getCurrentUser gets the current user.
func getCurrentUser() *user.User {
	currentUser, err := user.Current()

	if err != nil {
		log.Fatal(err)
	}

	return currentUser
}

// getCurrentUserFullUsername gets the fully qualified login name of the current
// user.
func getCurrentUserFullUsername() string {
	currentUser := getCurrentUser()
	currentUserFullName := currentUser.Username

	return currentUserFullName
}

// getCurrentUserHomePath gets the path to the current user's home directory.
func getCurrentUserHomePath() string {
	currentUser := getCurrentUser()
	currentUserHomePath := currentUser.HomeDir

	return currentUserHomePath
}

// getCurrentUserUsername gets the login name of the current user.
func getCurrentUserUsername() string {
	currentUserFullName := getCurrentUserFullUsername()
	currentUserName := strings.TrimPrefix(currentUserFullName, "NWIE\\")

	return currentUserName
}
