package federator

import (
	"fmt"
	"net/url"
)

func getAbsoluteFormURL(u *url.URL, action string) (string, error) {
	switch action {
	case "?":
		u.RawQuery = ""
		// Split URI on.
		return u.String(), nil
	case "":
		// Exact URI.
		return u.String(), nil
	default:
		// This is either a relative or abolsute URI given.
		au, err := url.Parse(action)
		if err != nil {
			return "", fmt.Errorf("could not parse action: %s", err)
		}

		if au.IsAbs() {
			return action, nil
		}

		u.Path = action
		u.RawQuery = ""
		return u.String(), nil
	}
}
