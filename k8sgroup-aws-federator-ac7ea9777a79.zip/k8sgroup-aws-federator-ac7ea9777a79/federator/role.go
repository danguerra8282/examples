package federator

import (
	"fmt"
	"regexp"
	"strings"
)

// Role represents an AWS IAM role.
type Role string

// String creates a prettier representation of the raw RoleArn/PrincipalArn
// string.
func (role Role) String() string {
	// Doesn't match all valid characters according to documentation:
	// http://docs.aws.amazon.com/IAM/latest/UserGuide/reference_iam-limits.html
	re := regexp.MustCompile("arn:aws:iam::(\\d+):role/(\\w+)")
	stringSubmatches := re.FindStringSubmatch(string(role))

	return fmt.Sprintf("%s - %s", stringSubmatches[1], stringSubmatches[2])
}

// RoleARN returns a Role's role ARN.
func (role Role) RoleARN() string {
	return strings.Split(string(role), ",")[0]
}

// PrincipalARN returns a Role's principal ARN.
func (role Role) PrincipalARN() string {
	return strings.Split(string(role), ",")[1]
}

// AccountNumber returns a Role's AWS account number.
func (role Role) AccountNumber() string {
	re := regexp.MustCompile("arn:aws:iam::(\\d+):role")
	stringSubmatches := re.FindStringSubmatch(role.RoleARN())

	return stringSubmatches[1]
}

// RoleName returns a Role's role name.
func (role Role) RoleName() string {
	re := regexp.MustCompile("arn:aws:iam::\\d+:role/(\\S+)")
	stringSubmatches := re.FindStringSubmatch(role.RoleARN())

	return stringSubmatches[1]
}
