package federator

import (
	"fmt"
	"strings"

	"gopkg.in/ini.v1"
)

// WriteInput represents the input structure for the Writer.Write method.
type WriteInput struct {
	CredentialStructure Credential
	ProfileName         string
}

// Writer represents an INI file writer for AWS credentials.
type Writer struct {
	FilePath   string
	RegionName string
}

// NewWriter returns a new AWS Federator Writer.
func NewWriter(filePath string, regionName string) (Writer, error) {
	writer := Writer{
		FilePath:   filePath,
		RegionName: strings.TrimSpace(regionName),
	}

	return writer, nil
}

// Write writes an AWS credential to an INI file.
func (writer *Writer) Write(writeInput WriteInput) error {
	var profileName string

	credential := writeInput.CredentialStructure
	iniFile, err := ini.Load(writer.FilePath)

	if writeInput.ProfileName != "" {
		profileName = writeInput.ProfileName
	} else {
		profileName = writeInput.CredentialStructure.RoleName
	}

	if err != nil {
		return err
	}

	if _, err := iniFile.GetSection(profileName); err != nil {
		if _, err := iniFile.NewSection(profileName); err != nil {
			return fmt.Errorf("unable to create credential profile: %s", err)
		}
	}

	iniProfileSection, err := iniFile.GetSection(profileName)

	if err != nil {
		return fmt.Errorf("Unable to retrieve recently created profile: %s", err)
	}

	if credential.AccessKeyID != "" {
		if _, err := iniProfileSection.NewKey("aws_access_key_id", credential.AccessKeyID); err != nil {
			return fmt.Errorf("Unable to write 'aws_access_key_id' to file: %s", err)
		}
	}

	if credential.SecretAccessKey != "" {
		if _, err := iniProfileSection.NewKey("aws_secret_access_key", credential.SecretAccessKey); err != nil {
			return fmt.Errorf("Unable to write 'aws_secret_access_key' to file: %s", err)
		}
	}

	if credential.SessionToken != "" {
		if _, err := iniProfileSection.NewKey("aws_session_token", credential.SessionToken); err != nil {
			return fmt.Errorf("Unable to write 'aws_session_token' to file: %s", err)
		}
	}

	if writer.RegionName != "" {
		if _, err := iniProfileSection.NewKey("region", writer.RegionName); err != nil {
			return fmt.Errorf("Unable to write 'region' to file: %s", err)
		}
	}

	if credential.SessionToken != "" && credential.SecretAccessKey != "" && credential.AccessKeyID != "" {
		if err := iniFile.SaveTo(writer.FilePath); err != nil {
			return fmt.Errorf("Unable to save credential to disk: %s", err)
		}
	}

	return nil
}

// BatchWrite writes multiple AWS credentials to an INI file.
func (writer *Writer) BatchWrite(credentials []Credential) error {
	for _, credential := range credentials {
		writeInput := WriteInput{
			CredentialStructure: credential,
		}

		err := writer.Write(writeInput)

		if err != nil {
			return err
		}
	}

	return nil
}
