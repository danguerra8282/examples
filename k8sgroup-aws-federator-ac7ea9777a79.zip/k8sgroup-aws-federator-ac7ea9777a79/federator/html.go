package federator

import (
	"fmt"

	"golang.org/x/net/html"
)

func findHTMLAttributeValue(key string, a []html.Attribute) (string, error) {
	for _, attr := range a {
		if key == attr.Key {
			return attr.Val, nil
		}
	}
	return "", fmt.Errorf("attribute does not exist: %s", key)
}
