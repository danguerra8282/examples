package federator_test

import (
	"os"
	"reflect"
	"testing"

	"github.nwie.net/nationwide/aws-federator/v3/federator"
)

// createClient creates a new federator.Client.
func createClient(t *testing.T) federator.Client {
	federatorClient, err := federator.NewClient(getUsername(t), getPassword(t), federator.DefaultLoginURL)

	if err != nil {
		t.Fatalf("error occurred while creating client: %s", err)
	}

	return federatorClient
}

// createInvalidClient creates a new federator.Client with invalid credentials.
func createInvalidClient(t *testing.T) federator.Client {
	federatorClient, err := federator.NewClient("", "", federator.DefaultLoginURL)

	if err != nil {
		t.Fatalf("error occurred while creating client: %s", err)
	}

	return federatorClient
}

// getPassword gets the test password.
func getPassword(t *testing.T) string {
	password := os.Getenv("AWS_FEDERATOR_TEST_PASSWORD")

	if password == "" {
		t.Fatal("the 'AWS_FEDERATOR_TEST_PASSWORD' environment variable is not set")
	}

	return password
}

// getUsername gets the test username.
func getUsername(t *testing.T) string {
	username := os.Getenv("AWS_FEDERATOR_TEST_USERNAME")

	if username == "" {
		t.Fatal("the 'AWS_FEDERATOR_TEST_USERNAME' environment variable is not set")
	}

	return username
}

// TestAssumeAllRoles tests the federator.Client.AssumeAllRoles method.
func TestAssumeAllRoles(t *testing.T) {
	federatorClient := createClient(t)
	err := federatorClient.Login()

	if err != nil {
		t.Fatalf("error occurred while logging in: %s", err)
	}

	credentials, err := federatorClient.AssumeAllRoles(int64(3600))

	if err != nil {
		t.Fatalf("error occurred while assuming all roles: %s", err)
	}

	if reflect.TypeOf(credentials).String() != "[]federator.Credential" {
		t.Fatal("did not return '[]federator.Credential' type")
	}

	if len(credentials) < 1 {
		t.Fatal("no credentials returned")
	}

	credential := credentials[0]

	if err != nil {
		t.Fatalf("error occurred while assuming role: %s", err)
	}

	if reflect.TypeOf(credential).String() != "federator.Credential" {
		t.Fatal("did not return 'federator.Credential' type")
	}

	if len(credential.AccountNumber) < 1 {
		t.Fatal("credential's 'AccountNumber' field is empty")
	}

	if len(credential.RoleName) < 1 {
		t.Fatal("credential's 'RoleName' field is empty")
	}

	if len(credential.RoleARN) < 1 {
		t.Fatal("credential's 'RoleARN' field is empty")
	}

	if len(credential.PrincipalARN) < 1 {
		t.Fatal("credential's 'PrincipalARN' field is empty")
	}

	if len(credential.AccessKeyID) < 1 {
		t.Fatal("credential's 'AccessKeyID' field is empty")
	}

	if len(credential.SecretAccessKey) < 1 {
		t.Fatal("credential's 'SecretAccessKey' field is empty")
	}

	if len(credential.SessionToken) < 1 {
		t.Fatal("credential's 'SessionToken' field is empty")
	}

	_, err = federatorClient.AssumeAllRoles(int64(0))

	if err == nil {
		t.Fatal("error did not occur due to invalid duration seconds of 0")
	}
}

// TestAssumeRole tests the federator.Client.AssumeRole method.
func TestAssumeRole(t *testing.T) {
	federatorClient := createClient(t)
	err := federatorClient.Login()

	if err != nil {
		t.Fatalf("error occurred while logging in: %s", err)
	}

	roles, err := federatorClient.GetRoles()

	if err != nil {
		t.Fatalf("error occurred while getting roles: %s", err)
	}

	credential, err := federatorClient.AssumeRole(roles[0], int64(3600))

	if err != nil {
		t.Fatalf("error occurred while assuming role: %s", err)
	}

	if reflect.TypeOf(credential).String() != "federator.Credential" {
		t.Fatal("did not return 'federator.Credential' type")
	}

	if len(credential.AccountNumber) < 1 {
		t.Fatal("credential's 'AccountNumber' field is empty")
	}

	if len(credential.RoleName) < 1 {
		t.Fatal("credential's 'RoleName' field is empty")
	}

	if len(credential.RoleARN) < 1 {
		t.Fatal("credential's 'RoleARN' field is empty")
	}

	if len(credential.PrincipalARN) < 1 {
		t.Fatal("credential's 'PrincipalARN' field is empty")
	}

	if len(credential.AccessKeyID) < 1 {
		t.Fatal("credential's 'AccessKeyID' field is empty")
	}

	if len(credential.SecretAccessKey) < 1 {
		t.Fatal("credential's 'SecretAccessKey' field is empty")
	}

	if len(credential.SessionToken) < 1 {
		t.Fatal("credential's 'SessionToken' field is empty")
	}

	_, err = federatorClient.AssumeRole(roles[0], int64(0))

	if err == nil {
		t.Fatal("error did not occur due to invalid duration seconds of 0")
	}
}

// TestGetRoles tests the federator.Client.GetRoles method.
func TestGetRoles(t *testing.T) {
	federatorClient := createClient(t)
	err := federatorClient.Login()

	if err != nil {
		t.Fatalf("error occurred while logging in: %s", err)
	}

	roles, err := federatorClient.GetRoles()

	if err != nil {
		t.Fatalf("error occurred while getting roles: %s", err)
	}

	if len(roles) < 1 {
		t.Fatal("no roles returned")
	}
}

// TestLogin tests the federator.Client.Login method.
func TestLogin(t *testing.T) {
	federatorClient := createClient(t)
	err := federatorClient.Login()

	if err != nil {
		t.Fatalf("error occurred while logging in: %s", err)
	}

	invalidFederatorClient := createInvalidClient(t)
	err = invalidFederatorClient.Login()

	if err == nil {
		t.Fatal("error did not occur due to invalid credentials")
	}
}

// TestNewClient tests the NewClient function in the federator package.
func TestNewClient(t *testing.T) {
	federatorClient, err := federator.NewClient("username", "password", "https://httpbin.org/post")

	if err != nil {
		t.Fatalf("error occurred while creating client: %s", err)
	}

	if reflect.TypeOf(federatorClient).String() != "federator.Client" {
		t.Fatal("did not return 'federator.Client' type")
	}

	_, err = federator.NewClient("username", "password", "invalid_url")

	if err == nil {
		t.Fatal("error did not occur due to invalid URL")
	}
}
