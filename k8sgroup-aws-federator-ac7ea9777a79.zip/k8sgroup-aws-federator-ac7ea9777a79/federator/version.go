package federator

// Version is the version of the AWS Federator.
var Version = "development"
