package federator

import (
	"os"
)

// GetEnvironmentAccountName gets the environment variable value for the name of
// the configuration account to use.
func GetEnvironmentAccountName() string {
	return os.Getenv("AWS_FEDERATOR_ACCOUNT")
}

// GetEnvironmentConfigurationFilePath gets the environment variable value for
// the path of the configuration file.
func GetEnvironmentConfigurationFilePath() string {
	return os.Getenv("AWS_FEDERATOR_CONFIG_FILE")
}

// GetEnvironmentCredentialsFilePath gets the environment variable value for the
// path of the AWS credentials file.
func GetEnvironmentCredentialsFilePath() string {
	return os.Getenv("AWS_SHARED_CREDENTIALS_FILE")
}

// GetEnvironmentDefaultProfileName gets the environment variable value for the
// name of the AWS credentials profile to set as the default.
func GetEnvironmentDefaultProfileName() string {
	return os.Getenv("AWS_FEDERATOR_DEFAULT_PROFILE")
}

// GetEnvironmentDefaultRegionName gets the environment variable value for the
// name of the AWS region to set as the default for each credentials
// profile.
func GetEnvironmentDefaultRegionName() string {
	return os.Getenv("AWS_FEDERATOR_DEFAULT_REGION")
}

// GetEnvironmentDurationSeconds gets the environment variable value for the
// amount of time in seconds that the AWS credentials will be valid for.
func GetEnvironmentDurationSeconds() string {
	return os.Getenv("AWS_FEDERATOR_DURATION")
}

// GetEnvironmentExtraCredentialsFilePath gets the environment variable value
// for the path of the file containing additional AWS credentials.
func GetEnvironmentExtraCredentialsFilePath() string {
	return os.Getenv("AWS_FEDERATOR_EXTRA_CREDENTIALS_FILE")
}

// GetEnvironmentLoginURL gets the environment variable value for the URL of the
// identity provider's AWS service provider login.
func GetEnvironmentLoginURL() string {
	return os.Getenv("AWS_FEDERATOR_LOGIN_URL")
}

// GetEnvironmentPassword gets the environment variable value for the password
// to log in with.
func GetEnvironmentPassword() string {
	return os.Getenv("AWS_FEDERATOR_PASSWORD")
}

// GetEnvironmentPasswordFilePath gets the environment variable value for the
// path of the file containing the login password.
func GetEnvironmentPasswordFilePath() string {
	return os.Getenv("AWS_FEDERATOR_PASSWORD_FILE")
}

// GetEnvironmentUsername gets the environment variable value for the password
// to log in with.
func GetEnvironmentUsername() string {
	return os.Getenv("AWS_FEDERATOR_USERNAME")
}
