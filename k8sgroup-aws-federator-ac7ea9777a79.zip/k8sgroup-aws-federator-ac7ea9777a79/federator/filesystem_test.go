package federator_test

import (
	"io/ioutil"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.nwie.net/nationwide/aws-federator/v3/federator"
	"github.nwie.net/nationwide/aws-federator/v3/internal/testhelper"
)

// TestAppendToFile tests the AppendToFile function from the federator package.
func TestAppendToFile(t *testing.T) {
	// Define the test data.
	originalData := "This is line one of the original data.\n    This is line two of original data.\n"
	newData := "This is line one of the new data.\n    This is line two of new data."
	combinedData := strings.Join([]string{originalData, newData}, "")

	// Set up the test file.
	err := ioutil.WriteFile(testhelper.AppendFilePath, []byte(originalData), 0600)
	if err != nil {
		t.Fatalf("error occurred while writing initial test data to '%s': %s", testhelper.AppendFilePath, err)
	}

	// Append data to the test file.
	err = federator.AppendToFile(testhelper.AppendFilePath, newData)
	if err != nil {
		t.Fatalf("error occurred while appending data to '%s': %s", testhelper.AppendFilePath, err)
	}

	// Read data from the test file.
	readData, err := federator.ReadFile(testhelper.AppendFilePath)
	if err != nil {
		t.Fatalf("error occurred while reading '%s': %s", testhelper.AppendFilePath, err)
	}

	// Ensure data read from test file matches the expected result.
	if readData != combinedData {
		t.Fatalf("data read from '%s' does not match expected result\ngot:\n%s\nexpected:\n%s", testhelper.AppendFilePath, readData, combinedData)
	}

	// Remove the test file.
	err = os.Remove(testhelper.AppendFilePath)
	if err != nil {
		t.Fatalf("error occurred while removing '%s': %s", testhelper.AppendFilePath, err)
	}
}

// TestCreateDirectoryIfNotExists tests the CreateDirectoryIfNotExists function
// from the federator package.
func TestCreateDirectoryIfNotExists(t *testing.T) {
	// Remove the test directory if it already exists.
	if federator.FileSystemPathExists(testhelper.NewDirectoryPath) {
		err := os.Remove(testhelper.NewDirectoryPath)
		if err != nil {
			t.Fatalf("error occurred while attempting to remove '%s': %s", testhelper.NewDirectoryPath, err)
		}
	}

	// Create the test directory.
	err := federator.CreateDirectoryIfNotExists(testhelper.NewDirectoryPath, 0700)
	if err != nil {
		t.Fatalf("error occurred while attempting to create '%s': %s", testhelper.NewDirectoryPath, err)
	}

	// Ensure the test directory exists.
	if !federator.FileSystemPathExists(testhelper.NewDirectoryPath) {
		t.Fatalf("'%s' does not exist", testhelper.NewDirectoryPath)
	}

	// Remove the test directory.
	err = os.Remove(testhelper.NewDirectoryPath)
	if err != nil {
		t.Fatalf("error occurred while attempting to remove '%s': %s", testhelper.NewDirectoryPath, err)
	}
}

// TestCreateFileIfNotExists tests the CreateFileIfNotExists function from the
// federator package.
func TestCreateFileIfNotExists(t *testing.T) {
	// Remove the test file if it already exists.
	if federator.FileSystemPathExists(testhelper.NewTextFilePath) {
		err := os.Remove(testhelper.NewTextFilePath)
		if err != nil {
			t.Fatalf("error occurred while attempting to remove '%s': %s", testhelper.NewTextFilePath, err)
		}
	}

	// Create the test file.
	err := federator.CreateFileIfNotExists(testhelper.NewTextFilePath)
	if err != nil {
		t.Fatalf("error occurred while attempting to create '%s': %s", testhelper.NewTextFilePath, err)
	}

	// Ensure the test file exists.
	if !federator.FileSystemPathExists(testhelper.NewTextFilePath) {
		t.Fatalf("'%s' does not exist", testhelper.NewTextFilePath)
	}

	// Remove the test file.
	err = os.Remove(testhelper.NewTextFilePath)
	if err != nil {
		t.Fatalf("error occurred while attempting to remove '%s': %s", testhelper.NewTextFilePath, err)
	}
}

// TestFileSystemPathExists tests the FileSystemPathExists function from the
// federator package.
func TestFileSystemPathExists(t *testing.T) {
	if !federator.FileSystemPathExists(testhelper.TestDataDirectoryPath) {
		t.Fatalf("returned false even though '%s' exists", testhelper.TestDataDirectoryPath)
	}

	if !federator.FileSystemPathExists(testhelper.EmptyTextFilePath) {
		t.Fatalf("returned false even though '%s' exists", testhelper.EmptyTextFilePath)
	}

	if federator.FileSystemPathExists(testhelper.NonExistentTextFilePath) {
		t.Fatalf("returned true even though '%s' does not exist", testhelper.NonExistentTextFilePath)
	}
}

// TestGetFileSystemItemMode tests the GetFileSystemItemMode function from the
// federator package.
func TestGetFileSystemItemMode(t *testing.T) {
	// Define the path of the test file.
	testFilePath := filepath.Join(testhelper.TestDataDirectoryPath, "mode.txt")

	// Remove the test file if it already exists.
	if federator.FileSystemPathExists(testFilePath) {
		err := os.Remove(testFilePath)
		if err != nil {
			t.Fatalf("error occurred while attempting to remove '%s': %s", testFilePath, err)
		}
	}

	// Create the test file.
	err := federator.CreateFileIfNotExists(testFilePath)
	if err != nil {
		t.Fatalf("error occurred while attempting to create '%s': %s", testFilePath, err)
	}

	// Get the mode of the test file.
	mode, err := federator.GetFileSystemItemMode(testFilePath)
	if err != nil {
		t.Fatalf("error occurred while attempting to get mode of '%s': %s", testFilePath, err)
	}

	// Ensure the mode of the test file is 0666.
	if mode != 0666 {
		t.Fatalf("mode of '%s' is not 0666", testFilePath)
	}

	// Remove the test file.
	if federator.FileSystemPathExists(testFilePath) {
		err := os.Remove(testFilePath)
		if err != nil {
			t.Fatalf("error occurred while attempting to remove '%s': %s", testFilePath, err)
		}
	}

	// Attempt to get the mode of a non-existent test file.
	modeDeux, err := federator.GetFileSystemItemMode(testFilePath)

	// Ensure the mode is 0000. This is the value returned when a file system
	// item does not exist.
	if modeDeux != 0000 {
		t.Fatalf("mode is not 0000 due to '%s' not existing", testFilePath)
	}
}

// TestReadFile tests the ReadFile function from the federator package.
func TestReadFile(t *testing.T) {
	// Define the data expected to be read from the test file.
	expectedData := "Simple Text File\n\nThis is a simple text file.\n"

	// Set up the test file.
	err := ioutil.WriteFile(testhelper.SimpleTextFilePath, []byte(expectedData), 0600)
	if err != nil {
		t.Fatalf("error occurred while writing initial test data to '%s': %s", testhelper.SimpleTextFilePath, err)
	}

	// Read data from the test file.
	readData, err := federator.ReadFile(testhelper.SimpleTextFilePath)
	if err != nil {
		t.Fatalf("error occurred while reading '%s': %s", testhelper.SimpleTextFilePath, err)
	}

	// Ensure the data read from the test file matches the expected data.
	if readData != expectedData {
		t.Fatalf("data read from '%s' does not match expected result\ngot:\n%s\nexpected:\n%s", testhelper.SimpleTextFilePath, readData, expectedData)
	}

	// Remove the test file.
	err = os.Remove(testhelper.SimpleTextFilePath)
	if err != nil {
		t.Fatalf("error occurred while removing '%s': %s", testhelper.SimpleTextFilePath, err)
	}
}

// TestRemoveFileSystemItemIfExists tests the RemoveFileSystemItemIfExists
// function from the federator package.
func TestRemoveFileSystemItemIfExists(t *testing.T) {
	// Define the path of the test file.
	testFilePath := filepath.Join(testhelper.TestDataDirectoryPath, "remove.txt")

	// Create the test file if it does not alrady exist.
	err := federator.CreateFileIfNotExists(testFilePath)
	if err != nil {
		t.Fatalf("error occurred while attempting to create '%s': %s", testFilePath, err)
	}

	// Remove the test file.
	err = federator.RemoveFileSystemItemIfExists(testFilePath)
	if err != nil {
		t.Fatalf("error occurred while attempting to remove '%s': %s", testFilePath, err)
	}

	// Ensure the test file no longer exists.
	if federator.FileSystemPathExists(testFilePath) {
		t.Fatalf("'%s' still exists", testFilePath)
	}
}
