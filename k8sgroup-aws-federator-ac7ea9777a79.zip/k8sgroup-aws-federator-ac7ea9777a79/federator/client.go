package federator

import (
	"fmt"
	"net/http"
	"net/http/cookiejar"
	"net/url"
	"reflect"
	"strings"

	"github.com/RobotsAndPencils/go-saml"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/sts"
	"golang.org/x/net/html"
)

// Client represents an AWS federator client.
type Client struct {
	Username string
	Password string
	LoginURL string

	httpClient     *http.Client
	samlResponse   *saml.Response
	samlResponse64 string
}

// NewClient returns a new AWS Federator Client.
func NewClient(username, password, loginURL string) (Client, error) {
	if _, err := url.ParseRequestURI(loginURL); err != nil {
		return Client{}, fmt.Errorf("invalid identity provider login URL provided: %s", err)
	}

	federatorClient := Client{
		Username: username,
		Password: password,
		LoginURL: loginURL,
	}

	cookiejarObject, err := cookiejar.New(nil)

	if err != nil {
		return federatorClient, fmt.Errorf("could not create cookiejar: %s", err)
	}

	httpClient := &http.Client{
		Jar: cookiejarObject,
	}

	federatorClient.httpClient = httpClient

	return federatorClient, nil
}

// Login logs in to an identity provider's AWS service provider.
func (client *Client) Login() error {
	httpResponse, err := client.httpClient.Get(client.LoginURL)

	if err != nil {
		return fmt.Errorf("could not retrieve identity provider login form: %s", err)
	}

	htmlForm, err := client.followFormSubmissionsToAWS(httpResponse)

	if err != nil {
		return fmt.Errorf("unable to get SAML response: %s", err)
	}

	if _, exists := htmlForm.Values["SAMLResponse"]; !exists {
		return fmt.Errorf("authentication failed: AWS service provider reached without a SAML response")
	}

	samlResponse, err := saml.ParseEncodedResponse(htmlForm.Values["SAMLResponse"][0])

	if err != nil {
		return fmt.Errorf("unable to parse SAML response: %s", err)
	}

	client.samlResponse = samlResponse
	client.samlResponse64 = htmlForm.Values["SAMLResponse"][0]

	return nil
}

// GetRoles gets all the AWS roles the authenticated user can assume.
func (client *Client) GetRoles() ([]Role, error) {
	var roleArray []Role

	roles := client.samlResponse.GetAttributeValues("https://aws.amazon.com/SAML/Attributes/Role")

	if len(roles) < 1 {
		return roleArray, fmt.Errorf("no AWS roles found in SAML response")
	}

	for _, role := range roles {
		roleArray = append(roleArray, Role(role))
	}

	return roleArray, nil
}

// AssumeRole assumes an AWS role with SAML.
func (client *Client) AssumeRole(role Role, durationSeconds int64) (Credential, error) {
	if client.samlResponse == nil {
		return Credential{}, fmt.Errorf("no SAML response found: the Client's Login method must be called before assuming a role")
	}

	stsClient := sts.New(session.New())

	assumeRoleWithSAMLInput := &sts.AssumeRoleWithSAMLInput{
		PrincipalArn:    aws.String(role.PrincipalARN()),
		RoleArn:         aws.String(role.RoleARN()),
		SAMLAssertion:   aws.String(client.samlResponse64),
		DurationSeconds: aws.Int64(durationSeconds),
	}

	assumeRoleWithSAMLOutput, err := stsClient.AssumeRoleWithSAML(assumeRoleWithSAMLInput)

	if err != nil {
		return Credential{}, fmt.Errorf("unable to assume '%s' role: %s", role.RoleARN(), err)
	}

	return Credential{
		AccountNumber:   role.AccountNumber(),
		RoleName:        role.RoleName(),
		RoleARN:         role.RoleARN(),
		PrincipalARN:    role.PrincipalARN(),
		AccessKeyID:     *assumeRoleWithSAMLOutput.Credentials.AccessKeyId,
		Expiration:      *assumeRoleWithSAMLOutput.Credentials.Expiration,
		SecretAccessKey: *assumeRoleWithSAMLOutput.Credentials.SecretAccessKey,
		SessionToken:    *assumeRoleWithSAMLOutput.Credentials.SessionToken,
	}, nil
}

// AssumeAllRoles assumes all roles the authenticated user has access to.
func (client *Client) AssumeAllRoles(durationSeconds int64) ([]Credential, error) {
	var credentials []Credential

	roles, err := client.GetRoles()

	if err != nil {
		return credentials, err
	}

	for _, role := range roles {
		credential, err := client.AssumeRole(role, durationSeconds)

		if err != nil {
			return credentials, err
		}

		credentials = append(credentials, credential)
	}

	return credentials, nil
}

func (client *Client) fillForm(httpResponse *http.Response) (loginForm, error) {
	currentLoginForm := loginForm{}
	currentLoginForm.Values = make(url.Values)

	// Defer httpResponse.Body.Close()
	htmlTokenizer := html.NewTokenizer(httpResponse.Body)

NodeLoop:
	for {
		htmlTokenType := htmlTokenizer.Next()

		if htmlTokenType == html.ErrorToken {
			// End of document. We are done.
			break NodeLoop
		} else if htmlTokenType == html.SelfClosingTagToken || htmlTokenType == html.StartTagToken {
			htmlToken := htmlTokenizer.Token()

			if htmlToken.Data == "form" {
				action, err := findHTMLAttributeValue("action", htmlToken.Attr)

				if err != nil {
					// Form doesnt have action field.
					break
				}

				currentLoginForm.URL, err = getAbsoluteFormURL(httpResponse.Request.URL, action)

				if err != nil {
					// Invalid action given. Should we abort or continue?
					break
				}
			} else if htmlToken.Data == "input" {
				htmlNameAttributeValue, err := findHTMLAttributeValue("name", htmlToken.Attr)

				if err != nil {
					continue // Element does not have name key.
				}

				switch {
				case strings.Contains(strings.ToLower(htmlNameAttributeValue), "user"):
					currentLoginForm.Values.Add(htmlNameAttributeValue, client.Username)
				case strings.Contains(strings.ToLower(htmlNameAttributeValue), "pass"):
					currentLoginForm.Values.Add(htmlNameAttributeValue, client.Password)
				default:
					htmlValueAtrributeValue, err := findHTMLAttributeValue("value", htmlToken.Attr)

					if err != nil {
						continue // Element does not have value key.
					}

					currentLoginForm.Values.Add(htmlNameAttributeValue, htmlValueAtrributeValue)
				}
			}
		}
	}

	return currentLoginForm, nil
}

// followFormSubmissionsToSP parses an http.Response object for form fields.
// When form fields are found, the method will attempt to substitute the
// configured username and password values into their respective form fields.
// Once the redirects have reached the AWS SAML service provider, the method
// will return the filled form that should contain the SAMLResponse field.
func (client Client) followFormSubmissionsToAWS(httpResponse *http.Response) (loginForm, error) {
	currentHTTPResponse := httpResponse
	count := 0 // Basic checker to ensure we are not stuck in a post loop.
	lastLoginForm := loginForm{}

	for {
		// Arbitrary number to try and detect a redirect loop.
		if count >= 6 {
			return loginForm{}, fmt.Errorf("could not reach AWS service provider due to redirect loop")
		}

		currentLoginForm, err := client.fillForm(currentHTTPResponse)

		if err != nil {
			fmt.Printf("unable to continue due to error while getting login form")
		}

		// Check if the form has been posted already (possibly wrong password).
		if lastLoginForm.URL == currentLoginForm.URL {
			if match := reflect.DeepEqual(lastLoginForm.Values, currentLoginForm.Values); match {
				return loginForm{}, fmt.Errorf("invalid username or password")
			}
		}

		lastLoginForm = currentLoginForm
		currentLoginFormURL, err := url.Parse(currentLoginForm.URL)

		if err != nil {
			return loginForm{}, fmt.Errorf("invalid login URL")
		}

		// Redirects have taken us to the AWS SAML endpoint. It has been
		// successful.
		if currentLoginFormURL.Host == "signin.aws.amazon.com" {
			lastLoginForm = currentLoginForm

			break
		}

		httpPostResponse, err := client.httpClient.PostForm(currentLoginForm.URL, currentLoginForm.Values)

		if err != nil {
			fmt.Printf("the HTTP POST request for the login form failed: %s", err)
			return loginForm{}, err
		}

		count++

		currentHTTPResponse = httpPostResponse
	}

	return lastLoginForm, nil
}
