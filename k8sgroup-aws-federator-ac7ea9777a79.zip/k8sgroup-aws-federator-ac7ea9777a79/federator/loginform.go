package federator

import (
	"net/url"
)

type loginForm struct {
	URL    string
	Values url.Values
}
