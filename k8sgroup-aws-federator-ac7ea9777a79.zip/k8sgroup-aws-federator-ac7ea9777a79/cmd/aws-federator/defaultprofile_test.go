package main

import (
	"testing"

	"github.nwie.net/nationwide/aws-federator/v3/internal/testhelper"
	"gopkg.in/ini.v1"
)

// TestSetDefaultProfile tests the SetDefaultProfile function from the main
// package.
func TestSetDefaultProfile(t *testing.T) {
	originalCredentials, err := ini.Load(testhelper.CredentialsFilePath)

	// Ensure no error occurred while loading original credentials.
	if err != nil {
		t.Fatalf("error occurred while loading original credentials from '%s': %s", testhelper.CredentialsFilePath, err)
	}

	// Set the default profile.
	err = SetDefaultProfile(testhelper.CredentialsFilePath, testhelper.AWSProfileName2)

	// Ensure no error occurred while setting the default profile.
	if err != nil {
		t.Fatalf("error occurred while setting default profile to '%s': %s", testhelper.AWSProfileName2, err)
	}

	// Load the updated credentials.
	updatedCredentials, err := ini.Load(testhelper.CredentialsFilePath)
	if err != nil {
		t.Fatalf("error occurred while loading updated credentials from '%s': %s", testhelper.CredentialsFilePath, err)
	}

	// Ensure the default profile exists.
	defaultProfile, err := updatedCredentials.GetSection("default")
	if err != nil {
		t.Fatalf("error occurred while getting 'default' profile from '%s': %s", testhelper.CredentialsFilePath, err)
	}

	// Ensure the default profile's aws_access_key_id value is correct.
	if defaultProfile.Key("aws_access_key_id").Value() != testhelper.AWSAccessKeyID2 {
		t.Fatalf("got incorrect 'aws_access_key_id' value for 'default' profile\ngot: %s\nexpected: %s", defaultProfile.Key("aws_access_key_id").Value(), testhelper.AWSAccessKeyID2)
	}

	// Ensure the default profile's aws_secret_access_key value is correct.
	if defaultProfile.Key("aws_secret_access_key").Value() != testhelper.AWSSecretAccessKey2 {
		t.Fatalf("got incorrect 'aws_secret_access_key' value for 'default' profile\ngot: %s\nexpected: %s", defaultProfile.Key("aws_access_key_id").Value(), testhelper.AWSSecretAccessKey2)
	}

	// Ensure the default profile's aws_session_token value is correct.
	if defaultProfile.Key("aws_session_token").Value() != testhelper.AWSSessionToken2 {
		t.Fatalf("got incorrect 'aws_session_token' value for 'default' profile\ngot: %s\nexpected: %s", defaultProfile.Key("aws_access_key_id").Value(), testhelper.AWSSessionToken2)
	}

	// Ensure the original aws-profile-name-1 profile exists.
	profile1, err := updatedCredentials.GetSection(testhelper.AWSProfileName1)
	if err != nil {
		t.Fatalf("error occurred while getting 'default' profile from '%s': %s", testhelper.CredentialsFilePath, err)
	}

	// Ensure the original aws-profile-name-1 profile's aws_access_key_id value is correct.
	if profile1.Key("aws_access_key_id").Value() != testhelper.AWSAccessKeyID1 {
		t.Fatalf("got incorrect 'aws_access_key_id' value for '%s' profile\ngot: %s\nexpected: %s", testhelper.AWSProfileName1, profile1.Key("aws_access_key_id").Value(), testhelper.AWSAccessKeyID1)
	}

	// Ensure the original aws-profile-name-1 profile's aws_secret_access_key value is correct.
	if profile1.Key("aws_secret_access_key").Value() != testhelper.AWSSecretAccessKey1 {
		t.Fatalf("got incorrect 'aws_secret_access_key' value for '%s' profile\ngot: %s\nexpected: %s", testhelper.AWSProfileName1, profile1.Key("aws_access_key_id").Value(), testhelper.AWSSecretAccessKey1)
	}

	// Ensure the original aws-profile-name-1 profile's aws_session_token value is correct.
	if profile1.Key("aws_session_token").Value() != testhelper.AWSSessionToken1 {
		t.Fatalf("got incorrect 'aws_session_token' value for '%s' profile\ngot: %s\nexpected: %s", testhelper.AWSProfileName1, profile1.Key("aws_access_key_id").Value(), testhelper.AWSSessionToken1)
	}

	// Ensure the original aws-profile-name-2 profile exists.
	profile2, err := updatedCredentials.GetSection(testhelper.AWSProfileName2)
	if err != nil {
		t.Fatalf("error occurred while getting 'default' profile from '%s': %s", testhelper.CredentialsFilePath, err)
	}

	// Ensure the original aws-profile-name-2 profile's aws_access_key_id value is correct.
	if profile2.Key("aws_access_key_id").Value() != testhelper.AWSAccessKeyID2 {
		t.Fatalf("got incorrect 'aws_access_key_id' value for '%s' profile\ngot: %s\nexpected: %s", testhelper.AWSProfileName2, profile2.Key("aws_access_key_id").Value(), testhelper.AWSAccessKeyID2)
	}

	// Ensure the original aws-profile-name-2 profile's aws_secret_access_key value is correct.
	if profile2.Key("aws_secret_access_key").Value() != testhelper.AWSSecretAccessKey2 {
		t.Fatalf("got incorrect 'aws_secret_access_key' value for '%s' profile\ngot: %s\nexpected: %s", testhelper.AWSProfileName2, profile2.Key("aws_access_key_id").Value(), testhelper.AWSSecretAccessKey2)
	}

	// Ensure the original aws-profile-name-2 profile's aws_session_token value is correct.
	if profile2.Key("aws_session_token").Value() != testhelper.AWSSessionToken2 {
		t.Fatalf("got incorrect 'aws_session_token' value for '%s' profile\ngot: %s\nexpected: %s", testhelper.AWSProfileName2, profile2.Key("aws_access_key_id").Value(), testhelper.AWSSessionToken2)
	}

	// Ensure an error occurs if attempting to set a non-existent profile as the
	// default.
	err = SetDefaultProfile(testhelper.CredentialsFilePath, "non-existent-profile-name")
	if err == nil {
		t.Fatal("error did not occur when attempting to set a non-existent profile as the default")
	}

	// Ensure an error occurs if attempting to set a profile as the default in a
	// non-existent credentials file.
	err = SetDefaultProfile(testhelper.NonExistentTextFilePath, testhelper.AWSProfileName2)
	if err == nil {
		t.Fatal("error did not occur when attempting to set a default profile in a non-existent credentials file")
	}

	// Reset the credentials file back to its original state.
	err = originalCredentials.SaveTo(testhelper.CredentialsFilePath)

	// Ensure no error occurred while resetting credentials back to original
	// state.
	if err != nil {
		t.Fatalf("error occurred while resetting credentials in '%s' to original state: %s", testhelper.CredentialsFilePath, err)
	}
}
