package main

import (
	"github.nwie.net/nationwide/aws-federator/v3/federator"
)

// AddExtraCredentials adds extra AWS credentials to the shared AWS credentials
// file.
func AddExtraCredentials(credentialsFilePath string, extraCredentialsFilePath string) error {
	if federator.FileSystemPathExists(extraCredentialsFilePath) {
		extraCredentialsData, err := federator.ReadFile(extraCredentialsFilePath)
		if err != nil {
			return err
		}

		err = federator.AppendToFile(credentialsFilePath, extraCredentialsData)
		if err != nil {
			return err
		}
	}

	return nil
}
