package main

import (
	"github.nwie.net/nationwide/aws-federator/v3/federator"
	"gopkg.in/ini.v1"
)

// Configuration represents the configuration data for the AWS Federator.
type Configuration struct {
	CredentialsFilePath      string
	DefaultProfileName       string
	DefaultRegionName        string
	DurationSeconds          int64
	ExtraCredentialsFilePath string
	LoginURL                 string
	PasswordFilePath         string
	Password                 string
	Username                 string
}

// NewConfiguration initializes and returns an instance of Configuration.
func NewConfiguration(filePath string, accountName string) (Configuration, error) {
	configuration := Configuration{}

	if federator.FileSystemPathExists(filePath) {
		iniFile, err := ini.Load(filePath)

		if err != nil {
			return configuration, err
		}

		iniFile.BlockMode = false

		var iniSection *ini.Section

		for _, currentIniSection := range iniFile.Sections() {
			if currentIniSection.Name() == accountName {
				iniSection = currentIniSection
			}
		}

		if iniSection.HasKey("credentialsfile") {
			credentialsFilePathKey, err := iniSection.GetKey("credentialsfile")
			if err != nil {
				return configuration, err
			}

			configuration.CredentialsFilePath = credentialsFilePathKey.Value()
		}

		if iniSection.HasKey("defaultprofile") {
			defaultProfileNameKey, err := iniSection.GetKey("defaultprofile")
			if err != nil {
				return configuration, err
			}

			configuration.DefaultProfileName = defaultProfileNameKey.Value()
		}

		if iniSection.HasKey("defaultregion") {
			defaultRegionNameKey, err := iniSection.GetKey("defaultregion")
			if err != nil {
				return configuration, err
			}

			configuration.DefaultRegionName = defaultRegionNameKey.Value()
		}

		if iniSection.HasKey("duration") {
			durationSecondsKey, err := iniSection.GetKey("duration")
			if err != nil {
				return configuration, err
			}

			durationSecondsValue, err := durationSecondsKey.Int64()
			if err != nil {
				return configuration, err
			}

			configuration.DurationSeconds = durationSecondsValue
		}

		if iniSection.HasKey("extracredentialsfile") {
			extraCredentialsFilePathKey, err := iniSection.GetKey("extracredentialsfile")
			if err != nil {
				return configuration, err
			}

			configuration.ExtraCredentialsFilePath = extraCredentialsFilePathKey.Value()
		}

		if iniSection.HasKey("loginurl") {
			loginURLKey, err := iniSection.GetKey("loginurl")
			if err != nil {
				return configuration, err
			}

			configuration.LoginURL = loginURLKey.Value()
		}

		if iniSection.HasKey("password") {
			passwordKey, err := iniSection.GetKey("password")
			if err != nil {
				return configuration, err
			}

			configuration.Password = passwordKey.Value()
		}

		if iniSection.HasKey("passwordfile") {
			passwordFilePathKey, err := iniSection.GetKey("passwordfile")
			if err != nil {
				return configuration, err
			}

			configuration.PasswordFilePath = passwordFilePathKey.Value()
		}

		if iniSection.HasKey("username") {
			usernameKey, err := iniSection.GetKey("username")
			if err != nil {
				return configuration, err
			}

			configuration.Username = usernameKey.Value()
		}
	}

	return configuration, nil
}
