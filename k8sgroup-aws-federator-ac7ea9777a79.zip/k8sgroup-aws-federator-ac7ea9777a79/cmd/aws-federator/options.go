package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"

	"github.com/howeyc/gopass"
	"github.nwie.net/nationwide/aws-federator/v3/federator"
)

// Options represents the AWS Federator command-line options.
type Options struct {
	AccountName              string
	ConfigurationFilePath    string
	CredentialsFilePath      string
	DefaultProfileName       string
	DefaultRegionName        string
	DurationSeconds          int64
	ExtraCredentialsFilePath string
	LoginURL                 string
	PasswordFilePath         string
	Password                 string
	Username                 string
	Verbose                  *bool
	Version                  *bool
}

// Set sets all the Options fields.
func (options *Options) Set(configuration Configuration) error {
	// Set the configuration file path option.
	err := options.SetConfigurationFilePath()
	if err != nil {
		return err
	}

	// Set the account option.
	err = options.SetAccountName()
	if err != nil {
		return err
	}

	// Set the credentials file path option.
	err = options.SetCredentialsFilePath(configuration)
	if err != nil {
		return err
	}

	// Set the duration seconds option.
	err = options.SetDurationSeconds(configuration)
	if err != nil {
		return err
	}

	// Set the default profile name option.
	err = options.SetDefaultProfileName(configuration)
	if err != nil {
		return err
	}

	// Set the default region name option.
	err = options.SetDefaultRegionName(configuration)
	if err != nil {
		return err
	}

	// Set the extra credentials file path option.
	err = options.SetExtraCredentialsFilePath(configuration)
	if err != nil {
		return err
	}

	// Set the login URL option.
	err = options.SetLoginURL(configuration)
	if err != nil {
		return err
	}

	// Set the username option.
	err = options.SetUsername(configuration)
	if err != nil {
		return err
	}

	// Set the password file path option.
	err = options.SetPasswordFilePath(configuration)
	if err != nil {
		return err
	}

	// Set the password option.
	err = options.SetPassword(configuration)
	if err != nil {
		return err
	}

	return nil
}

// SetAccountName sets the AccountName field value.
func (options *Options) SetAccountName() error {
	if options.AccountName == "" {
		if federator.GetEnvironmentAccountName() != "" {
			options.AccountName = federator.GetEnvironmentAccountName()
		} else {
			options.AccountName = federator.DefaultAccountName
		}
	}

	return nil
}

// SetConfigurationFilePath sets the ConfigurationFilePath field value.
func (options *Options) SetConfigurationFilePath() error {
	if options.ConfigurationFilePath == "" {
		if federator.GetEnvironmentConfigurationFilePath() != "" {
			options.ConfigurationFilePath = federator.GetEnvironmentConfigurationFilePath()
		} else {
			options.ConfigurationFilePath = federator.DefaultConfigurationFilePath
		}
	}

	return nil
}

// SetCredentialsFilePath sets the CredentialsFilePath field value.
func (options *Options) SetCredentialsFilePath(configuration Configuration) error {
	if options.CredentialsFilePath == "" {
		if federator.GetEnvironmentCredentialsFilePath() != "" {
			options.CredentialsFilePath = federator.GetEnvironmentCredentialsFilePath()
		} else if configuration.CredentialsFilePath != "" {
			options.CredentialsFilePath = configuration.CredentialsFilePath
		} else {
			options.CredentialsFilePath = federator.DefaultCredentialsFilePath
		}
	}

	return nil
}

// SetDurationSeconds sets the DurationSeconds field value.
func (options *Options) SetDurationSeconds(configuration Configuration) error {
	if options.DurationSeconds == 0 {
		if federator.GetEnvironmentDurationSeconds() != "" {
			environmentDurationSecondsInteger, err := strconv.ParseInt(federator.GetEnvironmentDurationSeconds(), 0, 64)
			if err != nil {
				return err
			}

			options.DurationSeconds = environmentDurationSecondsInteger
		} else if configuration.DurationSeconds != 0 {
			options.DurationSeconds = configuration.DurationSeconds
		} else {
			options.DurationSeconds = federator.DefaultDurationSeconds
		}
	}

	return nil
}

// SetDefaultProfileName sets the DefaultProfileName field value.
func (options *Options) SetDefaultProfileName(configuration Configuration) error {
	if options.DefaultProfileName == "" {
		if federator.GetEnvironmentDefaultProfileName() != "" {
			options.DefaultProfileName = federator.GetEnvironmentDefaultProfileName()
		} else if configuration.DefaultProfileName != "" {
			options.DefaultProfileName = configuration.DefaultProfileName
		}
	}

	return nil
}

// SetDefaultRegionName sets the DefaultRegionName field value.
func (options *Options) SetDefaultRegionName(configuration Configuration) error {
	if options.DefaultRegionName == "" {
		if federator.GetEnvironmentDefaultRegionName() != "" {
			options.DefaultRegionName = federator.GetEnvironmentDefaultRegionName()
		} else if configuration.DefaultRegionName != "" {
			options.DefaultRegionName = configuration.DefaultRegionName
		}
	}

	return nil
}

// SetExtraCredentialsFilePath sets the ExtraCredentialsFilePath field value.
func (options *Options) SetExtraCredentialsFilePath(configuration Configuration) error {
	if options.ExtraCredentialsFilePath == "" {
		if federator.GetEnvironmentExtraCredentialsFilePath() != "" {
			options.ExtraCredentialsFilePath = federator.GetEnvironmentExtraCredentialsFilePath()
		} else if configuration.ExtraCredentialsFilePath != "" {
			options.ExtraCredentialsFilePath = configuration.ExtraCredentialsFilePath
		} else {
			options.ExtraCredentialsFilePath = federator.DefaultExtraCredentialsFilePath
		}
	}

	return nil
}

// SetLoginURL sets the LoginURL field value.
func (options *Options) SetLoginURL(configuration Configuration) error {
	if options.LoginURL == "" {
		if federator.GetEnvironmentLoginURL() != "" {
			options.LoginURL = federator.GetEnvironmentLoginURL()
		} else if configuration.LoginURL != "" {
			options.LoginURL = configuration.LoginURL
		} else {
			options.LoginURL = federator.DefaultLoginURL
		}
	}

	return nil
}

// SetPassword sets the Username field value.
func (options *Options) SetPassword(configuration Configuration) error {
	if options.Password == "" {
		if federator.GetEnvironmentPassword() != "" {
			options.Password = federator.GetEnvironmentPassword()
		} else if federator.FileSystemPathExists(options.PasswordFilePath) {
			readPassword, err := federator.ReadFile(options.PasswordFilePath)

			if err != nil {
				return err
			}

			options.Password = strings.TrimSpace(string(readPassword))
		} else if configuration.Password != "" {
			options.Password = configuration.Password
		} else {
			fmt.Fprint(os.Stderr, "password: ")

			readPassword, err := gopass.GetPasswd()
			if err != nil {
				return err
			}

			options.Password = strings.TrimSpace(string(readPassword))
		}
	}

	return nil
}

// SetPasswordFilePath sets the PasswordFilePath field value.
func (options *Options) SetPasswordFilePath(configuration Configuration) error {
	if options.PasswordFilePath == "" {
		if federator.GetEnvironmentPasswordFilePath() != "" {
			options.PasswordFilePath = federator.GetEnvironmentPasswordFilePath()
		} else if configuration.PasswordFilePath != "" {
			options.PasswordFilePath = configuration.PasswordFilePath
		} else {
			options.PasswordFilePath = federator.DefaultPasswordFilePath
		}
	}

	return nil
}

// SetUsername sets the Username field value.
func (options *Options) SetUsername(configuration Configuration) error {
	if options.Username == "" {
		if federator.GetEnvironmentUsername() != "" {
			options.Username = federator.GetEnvironmentUsername()
		} else if configuration.Username != "" {
			options.Username = configuration.Username
		} else {
			bufferedIOReader := bufio.NewReader(os.Stdin)

			fmt.Fprint(os.Stderr, "username: ")

			readUsername, err := bufferedIOReader.ReadString('\n')
			if err != nil {
				return err
			}

			options.Username = strings.TrimSpace(readUsername)
		}
	}

	return nil
}
