package main

import (
	"gopkg.in/ini.v1"
)

// SetDefaultProfile sets the default AWS credentials profile.
func SetDefaultProfile(credentialsFilePath string, defaultProfileName string) error {
	// Load the existing credentials.
	iniFile, err := ini.Load(credentialsFilePath)
	if err != nil {
		return err
	}

	// Get the source profile to set as the default.
	iniSourceSection, err := iniFile.GetSection(defaultProfileName)
	if err != nil {
		return err
	}

	// Get the keys of the source profile.
	iniKeys := iniSourceSection.Keys()

	// Only proceed if the profile has keys.
	if len(iniKeys) > 0 {
		// Initialize the default profile.
		iniTargetSection, err := iniFile.NewSection("default")
		if err != nil {
			return err
		}

		// Add all the keys from the source profile to the target default
		// profile.
		for _, iniKey := range iniKeys {
			_, err := iniTargetSection.NewKey(iniKey.Name(), iniKey.Value())
			if err != nil {
				return err
			}
		}

		// Save the updated credentials.
		err = iniFile.SaveTo(credentialsFilePath)
		if err != nil {
			return err
		}
	}

	return nil
}
