package main

import (
	"testing"

	"github.nwie.net/nationwide/aws-federator/v3/internal/testhelper"
)

// TestNewConfiguration tests the NewConfiguration function in the main package.
func TestNewConfiguration(t *testing.T) {
	defaultConfiguration, err := NewConfiguration(testhelper.ConfigurationFilePath, "default")
	expectedDefaultCredentialsFilePath := "/path/to/credentials/file"
	expectedDefaultDefaultProfileName := "default-profile-name"
	expectedDefaultDefaultRegionName := "waste-central"
	expectedDefaultDurationSeconds := int64(28800)
	expectedDefaultExtraCredentialsFilePath := "/path/to/extra/credentials/file"
	expectedDefaultLoginURL := "https://example.com/sso/amazon-web-services"
	expectedDefaultPassword := "amnesiac"
	expectedDefaultPasswordFilePath := "/path/to/password/file"
	expectedDefaultUsername := "kida"

	// Ensure no error occurred while creating a new configuration object.
	if err != nil {
		t.Fatalf("error occurred while creating new configuration for 'default' account from '%s': %s", testhelper.ConfigurationFilePath, err)
	}

	// Ensure the CredentialsFilePath field value is correct for the default
	// account.
	if defaultConfiguration.CredentialsFilePath != expectedDefaultCredentialsFilePath {
		t.Fatalf("incorrect value for 'CredentialsFilePath' field\ngot: %s\nexpected: %s", defaultConfiguration.CredentialsFilePath, expectedDefaultCredentialsFilePath)
	}

	// Ensure the DefaultProfileName field value is correct for the default
	// account.
	if defaultConfiguration.DefaultProfileName != expectedDefaultDefaultProfileName {
		t.Fatalf("incorrect value for 'DefaultProfileName' field\ngot: %s\nexpected: %s", defaultConfiguration.DefaultProfileName, expectedDefaultDefaultProfileName)
	}

	// Ensure the DefaultRegionName field value is correct for the default
	// account.
	if defaultConfiguration.DefaultRegionName != expectedDefaultDefaultRegionName {
		t.Fatalf("incorrect value for 'DefaultRegionName' field\ngot: %s\nexpected: %s", defaultConfiguration.DefaultRegionName, expectedDefaultDefaultRegionName)
	}

	// Ensure the DurationSeconds field value is correct for the default
	// account.
	if defaultConfiguration.DurationSeconds != expectedDefaultDurationSeconds {
		t.Fatal("incorrect value for 'DurationSeconds' field value")
	}

	// Ensure the ExtraCredentialsFilePath field value is correct for the
	// default account.
	if defaultConfiguration.ExtraCredentialsFilePath != expectedDefaultExtraCredentialsFilePath {
		t.Fatalf("incorrect value for 'ExtraCredentialsFilePath' field\ngot: %s\nexpected: %s", defaultConfiguration.ExtraCredentialsFilePath, expectedDefaultExtraCredentialsFilePath)
	}

	// Ensure the LoginURL field value is correct for the default account.
	if defaultConfiguration.LoginURL != expectedDefaultLoginURL {
		t.Fatalf("incorrect value for 'LoginURL' field\ngot: %s\nexpected: %s", defaultConfiguration.LoginURL, expectedDefaultLoginURL)
	}

	// Ensure the Password field value is correct for the default account.
	if defaultConfiguration.Password != expectedDefaultPassword {
		t.Fatalf("incorrect value for 'Password' field\ngot: %s\nexpected: %s", defaultConfiguration.Password, expectedDefaultPassword)
	}

	// Ensure the PasswordFilePath field value is correct for the default
	// account.
	if defaultConfiguration.PasswordFilePath != expectedDefaultPasswordFilePath {
		t.Fatalf("incorrect value for 'PasswordFilePath' field\ngot: %s\nexpected: %s", defaultConfiguration.PasswordFilePath, expectedDefaultPasswordFilePath)
	}

	// Ensure the Username field value is correct for the default account.
	if defaultConfiguration.Username != expectedDefaultUsername {
		t.Fatalf("incorrect value for 'Username' field\ngot: %s\nexpected: %s", defaultConfiguration.Username, expectedDefaultUsername)
	}

	// Create a configuration object.
	customConfiguration, err := NewConfiguration(testhelper.ConfigurationFilePath, "custom")

	// Ensure no error occurred while creating a new configuration object.
	if err != nil {
		t.Fatalf("error occurred while creating new configuration for 'custom' account from '%s': %s", testhelper.ConfigurationFilePath, err)
	}

	// Ensure the CredentialsFilePath field value is a zero value for the custom
	// account.
	if customConfiguration.CredentialsFilePath != "" {
		t.Fatalf("'CredentialsFilePath' field is not a zero value")
	}

	// Ensure the DefaultProfileName field value is a zero value for the custom
	// account.
	if customConfiguration.DefaultProfileName != "" {
		t.Fatalf("'DefaultProfileName' field is not a zero value")
	}

	// Ensure the DefaultRegionName field value is a zero value for the custom
	// account.
	if customConfiguration.DefaultRegionName != "" {
		t.Fatalf("'DefaultRegionName' field is not a zero value")
	}

	// Ensure the DurationSeconds field value is a zero value for the custom
	// account.
	if customConfiguration.DurationSeconds != int64(0) {
		t.Fatal("incorrect value for 'DurationSeconds' field value")
	}

	// Ensure the ExtraCredentialsFilePath field value is a zero value for the
	// custom account.
	if customConfiguration.ExtraCredentialsFilePath != "" {
		t.Fatalf("'ExtraCredentialsFilePath' field is not a zero value")
	}

	// Ensure the LoginURL field value is a zero value for the custom account.
	if customConfiguration.LoginURL != "" {
		t.Fatalf("'LoginURL' field is not a zero value")
	}

	// Ensure the Password field value is a zero value for the custom account.
	if customConfiguration.Password != "" {
		t.Fatalf("'Password' field is not a zero value")
	}

	// Ensure the PasswordFilePath field value is a zero value for the custom
	// account.
	if customConfiguration.PasswordFilePath != "" {
		t.Fatalf("'PasswordFilePath' field is not a zero value")
	}

	// Ensure the Username field value is a zero value for the custom account.
	if customConfiguration.Username != "" {
		t.Fatalf("'Username' field is not a zero value")
	}

	// Create a configuration object.
	nonExistentConfiguration, err := NewConfiguration(testhelper.NonExistentTextFilePath, "non-existent-account")

	// Ensure no error occurred while creating a new configuration object.
	if err != nil {
		t.Fatalf("error occurred while creating new configuration for 'non-existent-account' account from '%s': %s", testhelper.NonExistentTextFilePath, err)
	}

	// Ensure the non-existent configuration object is a zero value.
	if nonExistentConfiguration != (Configuration{}) {
		t.Fatal("configuration object is not a zero value")
	}
}
