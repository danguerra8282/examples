package main

import (
	"reflect"
	"testing"

	"github.nwie.net/nationwide/aws-federator/v3/internal/testhelper"
	"gopkg.in/ini.v1"
)

// TestAddExtraCredentials tests the AddExtraCredentials from the main package.
func TestAddExtraCredentials(t *testing.T) {
	// Define variables for extra profiles.
	extraProfile1Name := "extra-profile-1"
	extraProfile1RoleARN := "extra-role-arn-1"
	extraProfile1SourceProfile := "aws-profile-name-1"
	extraProfile2Name := "extra-profile-2"
	extraProfile2RoleARN := "extra-role-arn-2"
	extraProfile2SourceProfile := "aws-profile-name-2"

	// Load the original credentials.
	originalCredentials, err := ini.Load(testhelper.CredentialsFilePath)
	if err != nil {
		t.Fatalf("error occurred while loading original credentials from '%s': %s", testhelper.CredentialsFilePath, err)
	}

	// Load the initial expected credentials.
	expectedCredentials, err := ini.Load(testhelper.CredentialsFilePath)
	if err != nil {
		t.Fatalf("error occurred while loading original credentials from '%s': %s", testhelper.CredentialsFilePath, err)
	}

	// Add extra profile 1 to expected credentials.
	extraProfile1, err := expectedCredentials.NewSection(extraProfile1Name)
	if err != nil {
		t.Fatalf("error occurred while adding '%s' profile to expected credentials: %s", extraProfile1Name, err)
	}

	// Add role ARN key to expected credentials extra profile 1.
	_, err = extraProfile1.NewKey("role_arn", extraProfile1RoleARN)
	if err != nil {
		t.Fatalf("error occurred while adding 'role_arn' key to '%s' expected credentials profile: %s", extraProfile1Name, err)
	}

	// Add source profile key to expected credentials extra profile 1.
	_, err = extraProfile1.NewKey("source_profile", extraProfile1SourceProfile)
	if err != nil {
		t.Fatalf("error occurred while adding 'source_profile' key to '%s' expected credentials profile: %s", extraProfile1Name, err)
	}

	// Add extra profile 1 to expected credentials.
	extraProfile2, err := expectedCredentials.NewSection(extraProfile2Name)
	if err != nil {
		t.Fatalf("error occurred while adding '%s' profile to expected credentials: %s", extraProfile2Name, err)
	}

	// Add role ARN key to expected credentials extra profile 2.
	_, err = extraProfile2.NewKey("role_arn", extraProfile2RoleARN)
	if err != nil {
		t.Fatalf("error occurred while adding 'role_arn' key to '%s' expected credentials profile: %s", extraProfile2Name, err)
	}

	// Add source profile key to expected credentials extra profile 2.
	_, err = extraProfile2.NewKey("source_profile", extraProfile2SourceProfile)
	if err != nil {
		t.Fatalf("error occurred while adding 'source_profile' key to '%s' expected credentials profile: %s", extraProfile2Name, err)
	}

	// Add extra credentials.
	err = AddExtraCredentials(testhelper.CredentialsFilePath, testhelper.ExtraCredentialsFilePath)

	// Ensure no error occurred while adding extra credentials.
	if err != nil {
		t.Fatalf("error occurred while add extra credentials from '%s' to '%s': %s", testhelper.ExtraCredentialsFilePath, testhelper.CredentialsFilePath, err)
	}

	// Load the updated credentials.
	updatedCredentials, err := ini.Load(testhelper.CredentialsFilePath)
	if err != nil {
		t.Fatalf("error occurred while loading updated credentials from '%s': %s", testhelper.CredentialsFilePath, err)
	}

	// Ensure the updated credentials match the expected credentials.
	if !reflect.DeepEqual(updatedCredentials, expectedCredentials) {
		t.Fatal("the updated credentials do not match the expected credentials")
	}

	// Reset the credentials file back to its original state.
	err = originalCredentials.SaveTo(testhelper.CredentialsFilePath)
	if err != nil {
		t.Fatalf("error occurred while resetting credentials in '%s' to original state: %s", testhelper.CredentialsFilePath, err)
	}
}
