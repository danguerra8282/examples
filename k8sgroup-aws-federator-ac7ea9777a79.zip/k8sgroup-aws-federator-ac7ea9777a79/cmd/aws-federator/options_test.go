package main

import (
	"testing"

	"github.nwie.net/nationwide/aws-federator/v3/federator"
	"github.nwie.net/nationwide/aws-federator/v3/internal/testhelper"
)

var (
	configurationCredentialsFilePath      = "/configuration/credentials/file/path"
	configurationDefaultProfileName       = "configuration-default-profile-name"
	configurationDefaultRegionName        = "configuration-default-region-name"
	configurationDurationSeconds          = int64(30)
	configurationExtraCredentialsFilePath = "/configuration/extra/credentials/file/path"
	configurationLoginURL                 = "configuration-login-url"
	configurationPasswordFilePath         = "/configuration/password/file/path"
	configurationPassword                 = "configuration-password"
	configurationUsername                 = "configuration-username"
)

// createConfiguration creates a Configuration structure for testing.
func createConfiguration() Configuration {
	return Configuration{
		CredentialsFilePath:      configurationCredentialsFilePath,
		DefaultProfileName:       configurationDefaultProfileName,
		DefaultRegionName:        configurationDefaultRegionName,
		DurationSeconds:          configurationDurationSeconds,
		ExtraCredentialsFilePath: configurationExtraCredentialsFilePath,
		LoginURL:                 configurationLoginURL,
		PasswordFilePath:         configurationPasswordFilePath,
		Password:                 configurationPassword,
		Username:                 configurationUsername,
	}
}

// createEmptyConfiguration creates an empty Configuration structure for testing.
func createEmptyConfiguration() Configuration {
	return Configuration{}
}

// createEmptyOptions creates an empty Options structure for testing.
func createEmptyOptions() Options {
	return Options{}
}

// unsetEnvironmentVariables unsets all environment variables used by the AWS
// Federator.
func setEnvironmentVariables(t *testing.T) {
	err := testhelper.SetEnvironmentVariables()
	if err != nil {
		t.Fatalf("error occurred while setting environment variables: %s", err)
	}
}

// unsetEnvironmentVariables unsets all environment variables used by the AWS
// Federator.
func unsetEnvironmentVariables(t *testing.T) {
	err := testhelper.UnsetEnvironmentVariables()
	if err != nil {
		t.Fatalf("error occurred while unsetting environment variables: %s", err)
	}
}

// TestOptionsSetAccountName tests the Options.SetAccountName method from the
// main package.
func TestOptionsSetAccountName(t *testing.T) {
	// Ensure all environment variables used by the AWS Federator are not set.
	unsetEnvironmentVariables(t)

	// Create an empty Options structure and set its AccountName field.
	options1 := createEmptyOptions()
	err := options1.SetAccountName()

	// Ensure no error occurred while setting AccountName.
	if err != nil {
		t.Fatalf("error occurred while setting 'AccountName' field: %s", err)
	}

	// Ensure the expected AccountName was set.
	if options1.AccountName != federator.DefaultAccountName {
		t.Fatalf("got unexpected 'AccountName'\ngot: %s\nexpected: %s", options1.AccountName, federator.DefaultAccountName)
	}

	// Ensure all environment variables used by the AWS Federator are set.
	setEnvironmentVariables(t)

	// Create an empty Options structure and set its AccountName field.
	options2 := createEmptyOptions()
	err = options2.SetAccountName()

	// Ensure no error occurred while setting AccountName.
	if err != nil {
		t.Fatalf("error occurred while setting 'AccountName' field: %s", err)
	}

	// Ensure the expected AccountName was set.
	if options2.AccountName != testhelper.EnvironmentAccountName {
		t.Fatalf("got unexpected 'AccountName'\ngot: %s\nexpected: %s", options2.AccountName, testhelper.EnvironmentAccountName)
	}

	// Create an empty Options structure, manually set the AccountName field,
	// and set its AccountName field through the SetAccountName method.
	options3 := createEmptyOptions()
	manualAccountName := "manual-account-name"
	options3.AccountName = manualAccountName
	err = options3.SetAccountName()

	// Ensure no error occurred while setting AccountName.
	if err != nil {
		t.Fatalf("error occurred while setting 'AccountName' field: %s", err)
	}

	// Ensure the expected AccountName was set.
	if options3.AccountName != manualAccountName {
		t.Fatalf("got unexpected 'AccountName'\ngot: %s\nexpected: %s", options3.AccountName, manualAccountName)
	}
}

// TestOptionsSetConfigurationFilePath tests the
// Options.SetConfigurationFilePath method from the main package.
func TestOptionsSetConfigurationFilePath(t *testing.T) {
	// Ensure all environment variables used by the AWS Federator are not set.
	unsetEnvironmentVariables(t)

	// Create an empty Options structure and set its ConfigurationFilePath field.
	options1 := createEmptyOptions()
	err := options1.SetConfigurationFilePath()

	// Ensure no error occurred while setting ConfigurationFilePath.
	if err != nil {
		t.Fatalf("error occurred while setting 'ConfigurationFilePath' field: %s", err)
	}

	// Ensure the expected ConfigurationFilePath was set.
	if options1.ConfigurationFilePath != federator.DefaultConfigurationFilePath {
		t.Fatalf("got unexpected 'ConfigurationFilePath'\ngot: %s\nexpected: %s", options1.ConfigurationFilePath, federator.DefaultConfigurationFilePath)
	}

	// Ensure all environment variables used by the AWS Federator are set.
	setEnvironmentVariables(t)

	// Create an empty Options structure and set its ConfigurationFilePath field.
	options2 := createEmptyOptions()
	err = options2.SetConfigurationFilePath()

	// Ensure no error occurred while setting ConfigurationFilePath.
	if err != nil {
		t.Fatalf("error occurred while setting 'ConfigurationFilePath' field: %s", err)
	}

	// Ensure the expected ConfigurationFilePath was set.
	if options2.ConfigurationFilePath != testhelper.EnvironmentConfigurationFilePath {
		t.Fatalf("got unexpected 'ConfigurationFilePath'\ngot: %s\nexpected: %s", options2.ConfigurationFilePath, testhelper.EnvironmentConfigurationFilePath)
	}

	// Create an empty Options structure, manually set the ConfigurationFilePath field,
	// and set its ConfigurationFilePath field through the SetConfigurationFilePath method.
	options3 := createEmptyOptions()
	manualConfigurationFilePath := "/manual/configuration/file/path"
	options3.ConfigurationFilePath = manualConfigurationFilePath
	err = options3.SetConfigurationFilePath()

	// Ensure no error occurred while setting ConfigurationFilePath.
	if err != nil {
		t.Fatalf("error occurred while setting 'ConfigurationFilePath' field: %s", err)
	}

	// Ensure the expected ConfigurationFilePath was set.
	if options3.ConfigurationFilePath != manualConfigurationFilePath {
		t.Fatalf("got unexpected 'ConfigurationFilePath'\ngot: %s\nexpected: %s", options3.ConfigurationFilePath, manualConfigurationFilePath)
	}
}

// TestOptionsSetCredentialsFilePath tests the Options.SetCredentialsFilePath
// method from the main package.
func TestOptionsSetCredentialsFilePath(t *testing.T) {
	// Ensure all environment variables used by the AWS Federator are not set.
	unsetEnvironmentVariables(t)

	// Create an empty Options structure and set its CredentialsFilePath field.
	options1 := createEmptyOptions()
	err := options1.SetCredentialsFilePath(createEmptyConfiguration())

	// Ensure no error occurred while setting CredentialsFilePath.
	if err != nil {
		t.Fatalf("error occurred while setting 'CredentialsFilePath' field: %s", err)
	}

	// Ensure the expected CredentialsFilePath was set.
	if options1.CredentialsFilePath != federator.DefaultCredentialsFilePath {
		t.Fatalf("got unexpected 'CredentialsFilePath'\ngot: %s\nexpected: %s", options1.CredentialsFilePath, federator.DefaultCredentialsFilePath)
	}

	// Create an empty Options structure and set its CredentialsFilePath field.
	options2 := createEmptyOptions()
	err = options2.SetCredentialsFilePath(createConfiguration())

	// Ensure no error occurred while setting CredentialsFilePath.
	if err != nil {
		t.Fatalf("error occurred while setting 'CredentialsFilePath' field: %s", err)
	}

	// Ensure the expected CredentialsFilePath was set.
	if options2.CredentialsFilePath != configurationCredentialsFilePath {
		t.Fatalf("got unexpected 'CredentialsFilePath'\ngot: %s\nexpected: %s", options2.CredentialsFilePath, configurationCredentialsFilePath)
	}

	// Ensure all environment variables used by the AWS Federator are set.
	setEnvironmentVariables(t)

	// Create an empty Options structure and set its CredentialsFilePath field.
	options3 := createEmptyOptions()
	err = options3.SetCredentialsFilePath(createConfiguration())

	// Ensure no error occurred while setting CredentialsFilePath.
	if err != nil {
		t.Fatalf("error occurred while setting 'CredentialsFilePath' field: %s", err)
	}

	// Ensure the expected CredentialsFilePath was set.
	if options3.CredentialsFilePath != testhelper.EnvironmentCredentialsFilePath {
		t.Fatalf("got unexpected 'CredentialsFilePath'\ngot: %s\nexpected: %s", options3.CredentialsFilePath, testhelper.EnvironmentCredentialsFilePath)
	}

	// Create an empty Options structure, manually set the CredentialsFilePath
	// field, and set its CredentialsFilePath field through the
	// SetCredentialsFilePath method.
	options4 := createEmptyOptions()
	manualCredentialsFilePath := "/manual/credentials/file/path"
	options4.CredentialsFilePath = manualCredentialsFilePath
	err = options4.SetCredentialsFilePath(createConfiguration())

	// Ensure no error occurred while setting CredentialsFilePath.
	if err != nil {
		t.Fatalf("error occurred while setting 'CredentialsFilePath' field: %s", err)
	}

	// Ensure the expected CredentialsFilePath was set.
	if options4.CredentialsFilePath != manualCredentialsFilePath {
		t.Fatalf("got unexpected 'CredentialsFilePath'\ngot: %s\nexpected: %s", options4.CredentialsFilePath, manualCredentialsFilePath)
	}
}

// TestOptionsSetDurationSeconds tests the Options.SetDurationSeconds method
// from the main package.
func TestOptionsSetDurationSeconds(t *testing.T) {
	// Ensure all environment variables used by the AWS Federator are not set.
	unsetEnvironmentVariables(t)

	// Create an empty Options structure and set its DurationSeconds field.
	options1 := createEmptyOptions()
	err := options1.SetDurationSeconds(createEmptyConfiguration())

	// Ensure no error occurred while setting DurationSeconds.
	if err != nil {
		t.Fatalf("error occurred while setting 'DurationSeconds' field: %s", err)
	}

	// Ensure the expected DurationSeconds was set.
	if options1.DurationSeconds != federator.DefaultDurationSeconds {
		t.Fatalf("got unexpected 'DurationSeconds'\ngot: %d\nexpected: %d", options1.DurationSeconds, federator.DefaultDurationSeconds)
	}

	// Create an empty Options structure and set its DurationSeconds field.
	options2 := createEmptyOptions()
	err = options2.SetDurationSeconds(createConfiguration())

	// Ensure no error occurred while setting DurationSeconds.
	if err != nil {
		t.Fatalf("error occurred while setting 'DurationSeconds' field: %s", err)
	}

	// Ensure the expected DurationSeconds was set.
	if options2.DurationSeconds != configurationDurationSeconds {
		t.Fatalf("got unexpected 'DurationSeconds'\ngot: %d\nexpected: %d", options2.DurationSeconds, configurationDurationSeconds)
	}

	// Ensure all environment variables used by the AWS Federator are set.
	setEnvironmentVariables(t)

	// Create an empty Options structure and set its DurationSeconds field.
	options3 := createEmptyOptions()
	err = options3.SetDurationSeconds(createConfiguration())

	// Ensure no error occurred while setting DurationSeconds.
	if err != nil {
		t.Fatalf("error occurred while setting 'DurationSeconds' field: %s", err)
	}

	// Ensure the expected DurationSeconds was set.
	if options3.DurationSeconds != testhelper.EnvironmentDurationSecondsInteger {
		t.Fatalf("got unexpected 'DurationSeconds'\ngot: %d\nexpected: %d", options3.DurationSeconds, testhelper.EnvironmentDurationSecondsInteger)
	}

	// Create an empty Options structure, manually set the DurationSeconds
	// field, and set its DurationSeconds field through the
	// SetDurationSeconds method.
	options4 := createEmptyOptions()
	manualDurationSeconds := int64(60)
	options4.DurationSeconds = manualDurationSeconds
	err = options4.SetDurationSeconds(createConfiguration())

	// Ensure no error occurred while setting DurationSeconds.
	if err != nil {
		t.Fatalf("error occurred while setting 'DurationSeconds' field: %s", err)
	}

	// Ensure the expected DurationSeconds was set.
	if options4.DurationSeconds != manualDurationSeconds {
		t.Fatalf("got unexpected 'DurationSeconds'\ngot: %d\nexpected: %d", options4.DurationSeconds, manualDurationSeconds)
	}
}

// TestOptionsSetDefaultProfileName tests the Options.SetDefaultProfileName
// method from the main package.
func TestOptionsSetDefaultProfileName(t *testing.T) {
	// Ensure all environment variables used by the AWS Federator are not set.
	unsetEnvironmentVariables(t)

	// Create an empty Options structure and set its DefaultProfileName field.
	options1 := createEmptyOptions()
	err := options1.SetDefaultProfileName(createEmptyConfiguration())

	// Ensure no error occurred while setting DefaultProfileName.
	if err != nil {
		t.Fatalf("error occurred while setting 'DefaultProfileName' field: %s", err)
	}

	// Ensure the expected DefaultProfileName was set.
	if options1.DefaultProfileName != "" {
		t.Fatalf("got unexpected 'DefaultProfileName'\ngot: %s\nexpected: %s", options1.DefaultProfileName, "")
	}

	// Create an empty Options structure and set its DefaultProfileName field.
	options2 := createEmptyOptions()
	err = options2.SetDefaultProfileName(createConfiguration())

	// Ensure no error occurred while setting DefaultProfileName.
	if err != nil {
		t.Fatalf("error occurred while setting 'DefaultProfileName' field: %s", err)
	}

	// Ensure the expected DefaultProfileName was set.
	if options2.DefaultProfileName != configurationDefaultProfileName {
		t.Fatalf("got unexpected 'DefaultProfileName'\ngot: %s\nexpected: %s", options2.DefaultProfileName, configurationDefaultProfileName)
	}

	// Ensure all environment variables used by the AWS Federator are set.
	setEnvironmentVariables(t)

	// Create an empty Options structure and set its DefaultProfileName field.
	options3 := createEmptyOptions()
	err = options3.SetDefaultProfileName(createConfiguration())

	// Ensure no error occurred while setting DefaultProfileName.
	if err != nil {
		t.Fatalf("error occurred while setting 'DefaultProfileName' field: %s", err)
	}

	// Ensure the expected DefaultProfileName was set.
	if options3.DefaultProfileName != testhelper.EnvironmentDefaultProfileName {
		t.Fatalf("got unexpected 'DefaultProfileName'\ngot: %s\nexpected: %s", options3.DefaultProfileName, testhelper.EnvironmentDefaultProfileName)
	}

	// Create an empty Options structure, manually set the DefaultProfileName
	// field, and set its DefaultProfileName field through the
	// SetDefaultProfileName method.
	options4 := createEmptyOptions()
	manualDefaultProfileName := "manual-default-profile-name"
	options4.DefaultProfileName = manualDefaultProfileName
	err = options4.SetDefaultProfileName(createConfiguration())

	// Ensure no error occurred while setting DefaultProfileName.
	if err != nil {
		t.Fatalf("error occurred while setting 'DefaultProfileName' field: %s", err)
	}

	// Ensure the expected DefaultProfileName was set.
	if options4.DefaultProfileName != manualDefaultProfileName {
		t.Fatalf("got unexpected 'DefaultProfileName'\ngot: %s\nexpected: %s", options4.DefaultProfileName, manualDefaultProfileName)
	}
}

// TestOptionsSetDefaultRegionName tests the Options.SetDefaultRegionName
// method from the main package.
func TestOptionsSetDefaultRegionName(t *testing.T) {
	// Ensure all environment variables used by the AWS Federator are not set.
	unsetEnvironmentVariables(t)

	// Create an empty Options structure and set its DefaultRegionName field.
	options1 := createEmptyOptions()
	err := options1.SetDefaultRegionName(createEmptyConfiguration())

	// Ensure no error occurred while setting DefaultRegionName.
	if err != nil {
		t.Fatalf("error occurred while setting 'DefaultRegionName' field: %s", err)
	}

	// Ensure the expected DefaultRegionName was set.
	if options1.DefaultRegionName != "" {
		t.Fatalf("got unexpected 'DefaultRegionName'\ngot: %s\nexpected: %s", options1.DefaultRegionName, "")
	}

	// Create an empty Options structure and set its DefaultRegionName field.
	options2 := createEmptyOptions()
	err = options2.SetDefaultRegionName(createConfiguration())

	// Ensure no error occurred while setting DefaultRegionName.
	if err != nil {
		t.Fatalf("error occurred while setting 'DefaultRegionName' field: %s", err)
	}

	// Ensure the expected DefaultRegionName was set.
	if options2.DefaultRegionName != configurationDefaultRegionName {
		t.Fatalf("got unexpected 'DefaultRegionName'\ngot: %s\nexpected: %s", options2.DefaultRegionName, configurationDefaultRegionName)
	}

	// Ensure all environment variables used by the AWS Federator are set.
	setEnvironmentVariables(t)

	// Create an empty Options structure and set its DefaultRegionName field.
	options3 := createEmptyOptions()
	err = options3.SetDefaultRegionName(createConfiguration())

	// Ensure no error occurred while setting DefaultRegionName.
	if err != nil {
		t.Fatalf("error occurred while setting 'DefaultRegionName' field: %s", err)
	}

	// Ensure the expected DefaultRegionName was set.
	if options3.DefaultRegionName != testhelper.EnvironmentDefaultRegionName {
		t.Fatalf("got unexpected 'DefaultRegionName'\ngot: %s\nexpected: %s", options3.DefaultRegionName, testhelper.EnvironmentDefaultRegionName)
	}

	// Create an empty Options structure, manually set the DefaultRegionName
	// field, and set its DefaultRegionName field through the
	// SetDefaultRegionName method.
	options4 := createEmptyOptions()
	manualDefaultRegionName := "manual-default-region-name"
	options4.DefaultRegionName = manualDefaultRegionName
	err = options4.SetDefaultRegionName(createConfiguration())

	// Ensure no error occurred while setting DefaultRegionName.
	if err != nil {
		t.Fatalf("error occurred while setting 'DefaultRegionName' field: %s", err)
	}

	// Ensure the expected DefaultRegionName was set.
	if options4.DefaultRegionName != manualDefaultRegionName {
		t.Fatalf("got unexpected 'DefaultRegionName'\ngot: %s\nexpected: %s", options4.DefaultRegionName, manualDefaultRegionName)
	}
}

// TestOptionsSetExtraCredentialsFilePath tests the
// Options.SetExtraCredentialsFilePath method from the main package.
func TestOptionsSetExtraCredentialsFilePath(t *testing.T) {
	// Ensure all environment variables used by the AWS Federator are not set.
	unsetEnvironmentVariables(t)

	// Create an empty Options structure and set its ExtraCredentialsFilePath field.
	options1 := createEmptyOptions()
	err := options1.SetExtraCredentialsFilePath(createEmptyConfiguration())

	// Ensure no error occurred while setting ExtraCredentialsFilePath.
	if err != nil {
		t.Fatalf("error occurred while setting 'ExtraCredentialsFilePath' field: %s", err)
	}

	// Ensure the expected ExtraCredentialsFilePath was set.
	if options1.ExtraCredentialsFilePath != federator.DefaultExtraCredentialsFilePath {
		t.Fatalf("got unexpected 'ExtraCredentialsFilePath'\ngot: %s\nexpected: %s", options1.ExtraCredentialsFilePath, federator.DefaultExtraCredentialsFilePath)
	}

	// Create an empty Options structure and set its ExtraCredentialsFilePath field.
	options2 := createEmptyOptions()
	err = options2.SetExtraCredentialsFilePath(createConfiguration())

	// Ensure no error occurred while setting ExtraCredentialsFilePath.
	if err != nil {
		t.Fatalf("error occurred while setting 'ExtraCredentialsFilePath' field: %s", err)
	}

	// Ensure the expected ExtraCredentialsFilePath was set.
	if options2.ExtraCredentialsFilePath != configurationExtraCredentialsFilePath {
		t.Fatalf("got unexpected 'ExtraCredentialsFilePath'\ngot: %s\nexpected: %s", options2.ExtraCredentialsFilePath, configurationExtraCredentialsFilePath)
	}

	// Ensure all environment variables used by the AWS Federator are set.
	setEnvironmentVariables(t)

	// Create an empty Options structure and set its ExtraCredentialsFilePath field.
	options3 := createEmptyOptions()
	err = options3.SetExtraCredentialsFilePath(createConfiguration())

	// Ensure no error occurred while setting ExtraCredentialsFilePath.
	if err != nil {
		t.Fatalf("error occurred while setting 'ExtraCredentialsFilePath' field: %s", err)
	}

	// Ensure the expected ExtraCredentialsFilePath was set.
	if options3.ExtraCredentialsFilePath != testhelper.EnvironmentExtraCredentialsFilePath {
		t.Fatalf("got unexpected 'ExtraCredentialsFilePath'\ngot: %s\nexpected: %s", options3.ExtraCredentialsFilePath, testhelper.EnvironmentExtraCredentialsFilePath)
	}

	// Create an empty Options structure, manually set the ExtraCredentialsFilePath
	// field, and set its ExtraCredentialsFilePath field through the
	// SetExtraCredentialsFilePath method.
	options4 := createEmptyOptions()
	manualExtraCredentialsFilePath := "/manual/extra/credentials/file/path"
	options4.ExtraCredentialsFilePath = manualExtraCredentialsFilePath
	err = options4.SetExtraCredentialsFilePath(createConfiguration())

	// Ensure no error occurred while setting ExtraCredentialsFilePath.
	if err != nil {
		t.Fatalf("error occurred while setting 'ExtraCredentialsFilePath' field: %s", err)
	}

	// Ensure the expected ExtraCredentialsFilePath was set.
	if options4.ExtraCredentialsFilePath != manualExtraCredentialsFilePath {
		t.Fatalf("got unexpected 'ExtraCredentialsFilePath'\ngot: %s\nexpected: %s", options4.ExtraCredentialsFilePath, manualExtraCredentialsFilePath)
	}
}

// TestOptionsSetLoginURL tests the Options.SetLoginURL method from the main
// package.
func TestOptionsSetLoginURL(t *testing.T) {
	// Ensure all environment variables used by the AWS Federator are not set.
	unsetEnvironmentVariables(t)

	// Create an empty Options structure and set its LoginURL field.
	options1 := createEmptyOptions()
	err := options1.SetLoginURL(createEmptyConfiguration())

	// Ensure no error occurred while setting LoginURL.
	if err != nil {
		t.Fatalf("error occurred while setting 'LoginURL' field: %s", err)
	}

	// Ensure the expected LoginURL was set.
	if options1.LoginURL != federator.DefaultLoginURL {
		t.Fatalf("got unexpected 'LoginURL'\ngot: %s\nexpected: %s", options1.LoginURL, federator.DefaultLoginURL)
	}

	// Create an empty Options structure and set its LoginURL field.
	options2 := createEmptyOptions()
	err = options2.SetLoginURL(createConfiguration())

	// Ensure no error occurred while setting LoginURL.
	if err != nil {
		t.Fatalf("error occurred while setting 'LoginURL' field: %s", err)
	}

	// Ensure the expected LoginURL was set.
	if options2.LoginURL != configurationLoginURL {
		t.Fatalf("got unexpected 'LoginURL'\ngot: %s\nexpected: %s", options2.LoginURL, configurationLoginURL)
	}

	// Ensure all environment variables used by the AWS Federator are set.
	setEnvironmentVariables(t)

	// Create an empty Options structure and set its LoginURL field.
	options3 := createEmptyOptions()
	err = options3.SetLoginURL(createConfiguration())

	// Ensure no error occurred while setting LoginURL.
	if err != nil {
		t.Fatalf("error occurred while setting 'LoginURL' field: %s", err)
	}

	// Ensure the expected LoginURL was set.
	if options3.LoginURL != testhelper.EnvironmentLoginURL {
		t.Fatalf("got unexpected 'LoginURL'\ngot: %s\nexpected: %s", options3.LoginURL, testhelper.EnvironmentLoginURL)
	}

	// Create an empty Options structure, manually set the LoginURL
	// field, and set its LoginURL field through the
	// SetLoginURL method.
	options4 := createEmptyOptions()
	manualLoginURL := "manual-login-url"
	options4.LoginURL = manualLoginURL
	err = options4.SetLoginURL(createConfiguration())

	// Ensure no error occurred while setting LoginURL.
	if err != nil {
		t.Fatalf("error occurred while setting 'LoginURL' field: %s", err)
	}

	// Ensure the expected LoginURL was set.
	if options4.LoginURL != manualLoginURL {
		t.Fatalf("got unexpected 'LoginURL'\ngot: %s\nexpected: %s", options4.LoginURL, manualLoginURL)
	}
}

// TestOptionsSetPassword tests the Options.SetPassword method from the main
// package.
func TestOptionsSetPassword(t *testing.T) {
	// Ensure all environment variables used by the AWS Federator are not set.
	unsetEnvironmentVariables(t)

	// TODO: Figure out how to test the password input prompt.

	// // Create an empty Options structure and set its Password field.
	// options1 := createEmptyOptions()
	// err := options1.SetPassword(createEmptyConfiguration())

	// // Ensure no error occurred while setting Password.
	// if err != nil {
	// 	t.Fatalf("error occurred while setting 'Password' field: %s", err)
	// }

	// // Ensure the expected Password was set.
	// if options1.Password != "" {
	// 	t.Fatalf("got unexpected 'Password'\ngot: %s\nexpected: %s", options1.Password, "")
	// }

	// Create an empty Options structure and set its Password field.
	options2 := createEmptyOptions()
	err := options2.SetPassword(createConfiguration())

	// Ensure no error occurred while setting Password.
	if err != nil {
		t.Fatalf("error occurred while setting 'Password' field: %s", err)
	}

	// Ensure the expected Password was set.
	if options2.Password != configurationPassword {
		t.Fatalf("got unexpected 'Password'\ngot: %s\nexpected: %s", options2.Password, configurationPassword)
	}

	// Create an empty Options structure, manually set its PasswordFilePath
	// field, and set its Password field.
	options3 := createEmptyOptions()
	options3.PasswordFilePath = testhelper.PasswordFilePath
	passwordFilePassword := "password-file-password"
	err = options3.SetPassword(createConfiguration())

	// Ensure no error occurred while setting Password.
	if err != nil {
		t.Fatalf("error occurred while setting 'Password' field: %s", err)
	}

	// Ensure the expected Password was set.
	if options3.Password != passwordFilePassword {
		t.Fatalf("got unexpected 'Password'\ngot: %s\nexpected: %s", options3.Password, passwordFilePassword)
	}

	// Ensure all environment variables used by the AWS Federator are set.
	setEnvironmentVariables(t)

	// Create an empty Options structure and set its Password field.
	options4 := createEmptyOptions()
	err = options4.SetPassword(createConfiguration())

	// Ensure no error occurred while setting Password.
	if err != nil {
		t.Fatalf("error occurred while setting 'Password' field: %s", err)
	}

	// Ensure the expected Password was set.
	if options4.Password != testhelper.EnvironmentPassword {
		t.Fatalf("got unexpected 'Password'\ngot: %s\nexpected: %s", options4.Password, testhelper.EnvironmentPassword)
	}

	// Create an empty Options structure, manually set the Password
	// field, and set its Password field through the
	// SetPassword method.
	options5 := createEmptyOptions()
	manualPassword := "manual-password"
	options5.Password = manualPassword
	err = options5.SetPassword(createConfiguration())

	// Ensure no error occurred while setting Password.
	if err != nil {
		t.Fatalf("error occurred while setting 'Password' field: %s", err)
	}

	// Ensure the expected Password was set.
	if options5.Password != manualPassword {
		t.Fatalf("got unexpected 'Password'\ngot: %s\nexpected: %s", options5.Password, manualPassword)
	}
}

// TestOptionsSetPasswordFilePath tests the Options.SetPasswordFilePath method
// from the main package.
func TestOptionsSetPasswordFilePath(t *testing.T) {
	// Ensure all environment variables used by the AWS Federator are not set.
	unsetEnvironmentVariables(t)

	// Create an empty Options structure and set its PasswordFilePath field.
	options1 := createEmptyOptions()
	err := options1.SetPasswordFilePath(createEmptyConfiguration())

	// Ensure no error occurred while setting PasswordFilePath.
	if err != nil {
		t.Fatalf("error occurred while setting 'PasswordFilePath' field: %s", err)
	}

	// Ensure the expected PasswordFilePath was set.
	if options1.PasswordFilePath != federator.DefaultPasswordFilePath {
		t.Fatalf("got unexpected 'PasswordFilePath'\ngot: %s\nexpected: %s", options1.PasswordFilePath, federator.DefaultPasswordFilePath)
	}

	// Create an empty Options structure and set its PasswordFilePath field.
	options2 := createEmptyOptions()
	err = options2.SetPasswordFilePath(createConfiguration())

	// Ensure no error occurred while setting PasswordFilePath.
	if err != nil {
		t.Fatalf("error occurred while setting 'PasswordFilePath' field: %s", err)
	}

	// Ensure the expected PasswordFilePath was set.
	if options2.PasswordFilePath != configurationPasswordFilePath {
		t.Fatalf("got unexpected 'PasswordFilePath'\ngot: %s\nexpected: %s", options2.PasswordFilePath, configurationPasswordFilePath)
	}

	// Ensure all environment variables used by the AWS Federator are set.
	setEnvironmentVariables(t)

	// Create an empty Options structure and set its PasswordFilePath field.
	options3 := createEmptyOptions()
	err = options3.SetPasswordFilePath(createConfiguration())

	// Ensure no error occurred while setting PasswordFilePath.
	if err != nil {
		t.Fatalf("error occurred while setting 'PasswordFilePath' field: %s", err)
	}

	// Ensure the expected PasswordFilePath was set.
	if options3.PasswordFilePath != testhelper.EnvironmentPasswordFilePath {
		t.Fatalf("got unexpected 'PasswordFilePath'\ngot: %s\nexpected: %s", options3.PasswordFilePath, testhelper.EnvironmentPasswordFilePath)
	}

	// Create an empty Options structure, manually set the PasswordFilePath
	// field, and set its PasswordFilePath field through the
	// SetPasswordFilePath method.
	options4 := createEmptyOptions()
	manualPasswordFilePath := "/manual/password/file/path"
	options4.PasswordFilePath = manualPasswordFilePath
	err = options4.SetPasswordFilePath(createConfiguration())

	// Ensure no error occurred while setting PasswordFilePath.
	if err != nil {
		t.Fatalf("error occurred while setting 'PasswordFilePath' field: %s", err)
	}

	// Ensure the expected PasswordFilePath was set.
	if options4.PasswordFilePath != manualPasswordFilePath {
		t.Fatalf("got unexpected 'PasswordFilePath'\ngot: %s\nexpected: %s", options4.PasswordFilePath, manualPasswordFilePath)
	}
}

// TestOptionsSetUsername tests the Options.SetUsername method from the main
// package.
func TestOptionsSetUsername(t *testing.T) {
	// Ensure all environment variables used by the AWS Federator are not set.
	unsetEnvironmentVariables(t)

	// TODO: Figure out how to test the username input prompt.

	// // Create an empty Options structure and set its Username field.
	// options1 := createEmptyOptions()
	// err := options1.SetUsername(createEmptyConfiguration())

	// // Ensure no error occurred while setting Username.
	// if err != nil {
	// 	t.Fatalf("error occurred while setting 'Username' field: %s", err)
	// }

	// // Ensure the expected Username was set.
	// if options1.Username != "" {
	// 	t.Fatalf("got unexpected 'Username'\ngot: %s\nexpected: %s", options1.Username, "")
	// }

	// Create an empty Options structure and set its Username field.
	options2 := createEmptyOptions()
	err := options2.SetUsername(createConfiguration())

	// Ensure no error occurred while setting Username.
	if err != nil {
		t.Fatalf("error occurred while setting 'Username' field: %s", err)
	}

	// Ensure the expected Username was set.
	if options2.Username != configurationUsername {
		t.Fatalf("got unexpected 'Username'\ngot: %s\nexpected: %s", options2.Username, configurationUsername)
	}

	// Ensure all environment variables used by the AWS Federator are set.
	setEnvironmentVariables(t)

	// Create an empty Options structure and set its Username field.
	options3 := createEmptyOptions()
	err = options3.SetUsername(createConfiguration())

	// Ensure no error occurred while setting Username.
	if err != nil {
		t.Fatalf("error occurred while setting 'Username' field: %s", err)
	}

	// Ensure the expected Username was set.
	if options3.Username != testhelper.EnvironmentUsername {
		t.Fatalf("got unexpected 'Username'\ngot: %s\nexpected: %s", options3.Username, testhelper.EnvironmentUsername)
	}

	// Create an empty Options structure, manually set the Username
	// field, and set its Username field through the
	// SetUsername method.
	options4 := createEmptyOptions()
	manualUsername := "manual-username"
	options4.Username = manualUsername
	err = options4.SetUsername(createConfiguration())

	// Ensure no error occurred while setting Username.
	if err != nil {
		t.Fatalf("error occurred while setting 'Username' field: %s", err)
	}

	// Ensure the expected Username was set.
	if options4.Username != manualUsername {
		t.Fatalf("got unexpected 'Username'\ngot: %s\nexpected: %s", options4.Username, manualUsername)
	}
}

// TestOptionsSet tests the Options.Set method from the main package.
func TestOptionsSet(t *testing.T) {
	// Ensure all environment variables used by the AWS Federator are set.
	setEnvironmentVariables(t)

	// Create an empty Options structure and set all its fields.
	options := createEmptyOptions()
	err := options.Set(createConfiguration())

	// Ensure no error occurred while setting Username.
	if err != nil {
		t.Fatalf("error occurred while setting all fields: %s", err)
	}

	// Ensure the expected AccountName was set.
	if options.AccountName != testhelper.EnvironmentAccountName {
		t.Fatalf("got unexpected 'AccountName'\ngot: %s\nexpected: %s", options.AccountName, testhelper.EnvironmentAccountName)
	}

	// Ensure the expected ConfigurationFilePath was set.
	if options.ConfigurationFilePath != testhelper.EnvironmentConfigurationFilePath {
		t.Fatalf("got unexpected 'ConfigurationFilePath'\ngot: %s\nexpected: %s", options.ConfigurationFilePath, testhelper.EnvironmentConfigurationFilePath)
	}

	// Ensure the expected CredentialsFilePath was set.
	if options.CredentialsFilePath != testhelper.EnvironmentCredentialsFilePath {
		t.Fatalf("got unexpected 'CredentialsFilePath'\ngot: %s\nexpected: %s", options.CredentialsFilePath, testhelper.EnvironmentCredentialsFilePath)
	}

	// Ensure the expected DefaultProfileName was set.
	if options.DefaultProfileName != testhelper.EnvironmentDefaultProfileName {
		t.Fatalf("got unexpected 'DefaultProfileName'\ngot: %s\nexpected: %s", options.DefaultProfileName, testhelper.EnvironmentDefaultProfileName)
	}

	// Ensure the expected DefaultRegionName was set.
	if options.DefaultRegionName != testhelper.EnvironmentDefaultRegionName {
		t.Fatalf("got unexpected 'DefaultRegionName'\ngot: %s\nexpected: %s", options.DefaultRegionName, testhelper.EnvironmentDefaultRegionName)
	}

	// Ensure the expected DurationSeconds was set.
	if options.DurationSeconds != testhelper.EnvironmentDurationSecondsInteger {
		t.Fatalf("got unexpected 'DurationSeconds'\ngot: %d\nexpected: %d", options.DurationSeconds, testhelper.EnvironmentDurationSecondsInteger)
	}

	// Ensure the expected ExtraCredentialsFilePath was set.
	if options.ExtraCredentialsFilePath != testhelper.EnvironmentExtraCredentialsFilePath {
		t.Fatalf("got unexpected 'ExtraCredentialsFilePath'\ngot: %s\nexpected: %s", options.ExtraCredentialsFilePath, testhelper.EnvironmentExtraCredentialsFilePath)
	}

	// Ensure the expected LoginURL was set.
	if options.LoginURL != testhelper.EnvironmentLoginURL {
		t.Fatalf("got unexpected 'LoginURL'\ngot: %s\nexpected: %s", options.LoginURL, testhelper.EnvironmentLoginURL)
	}

	// Ensure the expected PasswordFilePath was set.
	if options.PasswordFilePath != testhelper.EnvironmentPasswordFilePath {
		t.Fatalf("got unexpected 'PasswordFilePath'\ngot: %s\nexpected: %s", options.PasswordFilePath, testhelper.EnvironmentPasswordFilePath)
	}

	// Ensure the expected Password was set.
	if options.Password != testhelper.EnvironmentPassword {
		t.Fatalf("got unexpected 'Password'\ngot: %s\nexpected: %s", options.Password, testhelper.EnvironmentPassword)
	}

	// Ensure the expected Username was set.
	if options.Username != testhelper.EnvironmentUsername {
		t.Fatalf("got unexpected 'Username'\ngot: %s\nexpected: %s", options.Username, testhelper.EnvironmentUsername)
	}
}
