package main

import (
	"flag"
	"fmt"
	"io/ioutil"
	"log"
	"os"
	"path/filepath"

	"github.nwie.net/nationwide/aws-federator/v3/federator"
)

var (
	configuration Configuration
	logger        *log.Logger
	options       Options
)

func init() {
	flag.Int64Var(&options.DurationSeconds, "duration", int64(0), "amount of time in seconds that the AWS credentials will be valid for")
	flag.StringVar(&options.AccountName, "account", "", "name of the configuration account to use")
	flag.StringVar(&options.ConfigurationFilePath, "configfile", "", "path of the configuration file")
	flag.StringVar(&options.CredentialsFilePath, "credentialsfile", "", "path of the file that the AWS credentials will be written to")
	flag.StringVar(&options.DefaultProfileName, "defaultprofile", "", "name of the AWS credentials profile to set as the default")
	flag.StringVar(&options.DefaultRegionName, "defaultregion", "", "name of the AWS region to set as the default for each credentials profile")
	flag.StringVar(&options.ExtraCredentialsFilePath, "extracredentialsfile", "", "path of the file containing extra AWS credentials to add to the shared AWS credentials file")
	flag.StringVar(&options.LoginURL, "loginurl", "", "URL of the identity provider's AWS service provider login")
	flag.StringVar(&options.Password, "password", "", "the password to log in with")
	flag.StringVar(&options.PasswordFilePath, "passwordfile", "", "path of the file containing the login password")
	flag.StringVar(&options.Username, "username", "", "the username to log in with")

	options.Verbose = flag.Bool("verbose", false, "print debugging messages to standard error")
	options.Version = flag.Bool("version", false, "print version information and exit")

	flag.Usage = func() {
		fmt.Fprintf(os.Stderr, "NAME:\n")
		fmt.Fprintf(os.Stderr, "  aws-federator - easily manage federated AWS credentials from the command-line\n\n")
		fmt.Fprintf(os.Stderr, "USAGE:\n")
		fmt.Fprintf(os.Stderr, "  %s [<options>]\n\n", filepath.Base(os.Args[0]))
		fmt.Fprintf(os.Stderr, "VERSION:\n")
		fmt.Fprintf(os.Stderr, "  %s\n\n", federator.Version)
		fmt.Fprintf(os.Stderr, "OPTIONS:\n")
		flag.PrintDefaults()
		os.Exit(0)
	}
}

func main() {
	// Parse the command-line flags.
	flag.Parse()

	// Print version information and exit if the version flag was given.
	if *options.Version {
		fmt.Fprintf(os.Stderr, "%s\n", federator.Version)
		os.Exit(0)
	}

	// Create a new logger.
	logger = log.New(ioutil.Discard, "", log.LstdFlags)

	// Print debugging messages if the verbose flag was given.
	if *options.Verbose {
		logger.SetOutput(os.Stderr)
	}

	// Set value for configuration file path option.
	err := options.SetConfigurationFilePath()
	if err != nil {
		fmt.Fprintf(os.Stderr, "error occurred while setting configuration file path option value: %s\n", err)
		os.Exit(1)
	}

	// Set value for account name option.
	err = options.SetAccountName()
	if err != nil {
		fmt.Fprintf(os.Stderr, "error occurred while setting account name option value: %s\n", err)
		os.Exit(1)
	}

	// Load configuration data.
	configuration, err := NewConfiguration(options.ConfigurationFilePath, options.AccountName)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error occurred while loading configuration data: %s\n", err)
		os.Exit(1)
	}

	// Set values for all remaining options.
	err = options.Set(configuration)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error occurred while setting option values: %s\n", err)
		os.Exit(1)
	}

	// Initialize a new instance of the AWS Federator Client.
	federatorClient, err := federator.NewClient(options.Username, options.Password, options.LoginURL)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error occurred while initializing client: %s\n", err)
		os.Exit(1)
	}

	// Log in to the identity's provider AWS service provider.
	logger.Print("logging in to the identity provider's AWS service provider...")
	if err = federatorClient.Login(); err != nil {
		fmt.Fprintf(os.Stderr, "error occurred while logging in: %s\n", err)
		os.Exit(1)
	}

	// Get all the AWS roles the authenticated user has access to.
	roles, err := federatorClient.GetRoles()
	if err != nil {
		fmt.Fprintf(os.Stderr, "error occurred while getting roles: %s\n", err)
		os.Exit(1)
	}

	// Initialize a new instance of the AWS Federator Writer.
	federatorWriter, err := federator.NewWriter(options.CredentialsFilePath, options.DefaultRegionName)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error occurred while initializing writer: %s\n", err)
		os.Exit(1)
	}

	// Remove the credentials file if it already exists.
	err = federator.RemoveFileSystemItemIfExists(options.CredentialsFilePath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error occurred while removing '%s': %s\n", options.CredentialsFilePath, err)
		os.Exit(1)
	}

	// Get the absolute path of the credential file's directory.
	credentialsFileDirectoryPath, err := filepath.Abs(filepath.Dir(options.CredentialsFilePath))
	if err != nil {
		fmt.Fprintf(os.Stderr, "error occurred while getting absolute path of the directory of '%s': %s\n", options.CredentialsFilePath, err)
		os.Exit(1)
	}

	// Create the credentials file's directory if it does not already exist.
	err = federator.CreateDirectoryIfNotExists(credentialsFileDirectoryPath, 0700)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error occurred while creating '%s': %s\n", credentialsFileDirectoryPath, err)
		os.Exit(1)
	}

	// Create an empty credentials file.
	err = federator.CreateFileIfNotExists(options.CredentialsFilePath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error occurred while creating '%s': %s\n", options.CredentialsFilePath, err)
		os.Exit(1)
	}

	// Assume all roles the authenticated user has access to and get their
	// credentials.
	logger.Printf("getting all AWS credentials for '%s'...", options.Username)
	for _, role := range roles {
		credential, err := federatorClient.AssumeRole(role, options.DurationSeconds)
		if err != nil {
			fmt.Fprintf(os.Stderr, "error occurred while getting AWS credential for '%s': %s\n", role.RoleARN(), err)
			continue
		}

		// Write the credential to the credentials file.
		logger.Printf("writing AWS credential for '%s' to '%s'...", role.RoleARN(), options.CredentialsFilePath)
		federatorWriteInput := federator.WriteInput{
			CredentialStructure: credential,
		}
		err = federatorWriter.Write(federatorWriteInput)
		if err != nil {
			fmt.Fprintf(os.Stderr, "error occurred while writing AWS credential for '%s' to '%s': %s\n", role.RoleARN(), options.CredentialsFilePath, err)
			os.Exit(1)
		}
	}

	// Add any extra AWS credentials to the shared AWS credentials file.
	if federator.FileSystemPathExists(options.ExtraCredentialsFilePath) {
		logger.Printf("adding extra AWS credentials from '%s' to '%s'...", options.ExtraCredentialsFilePath, options.CredentialsFilePath)
	}
	err = AddExtraCredentials(options.CredentialsFilePath, options.ExtraCredentialsFilePath)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error occurred while adding extra credentials from '%s' to '%s': %s\n", options.ExtraCredentialsFilePath, options.CredentialsFilePath, err)
		os.Exit(1)
	}

	// Set the default AWS credentials profile.
	if options.DefaultProfileName != "" {
		logger.Printf("setting the default AWS credentials profile to '%s'...", options.DefaultProfileName)
	}
	err = SetDefaultProfile(options.CredentialsFilePath, options.DefaultProfileName)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error occurred while setting the default credentials profile to '%s' in '%s': %s\n", options.DefaultProfileName, options.CredentialsFilePath, err)
		os.Exit(1)
	}
}
